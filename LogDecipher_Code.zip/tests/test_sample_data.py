"""The fictional sample dataset must produce exactly the findings it was designed to contain."""
import unittest
from pathlib import Path

from logdecipher.engine.config import DetectionConfig
from logdecipher.engine.detector import analyze
from logdecipher.engine.parser import parse_login_csv
from logdecipher.engine.rules import (
    MULTI_ACCOUNT_FAILURES,
    REPEATED_FAILURES,
    SUCCESS_AFTER_FAILURES,
    UNUSUAL_TIME,
)
from logdecipher.engine.summary import build_summary, build_timeline, flagged_lines

SAMPLE = Path(__file__).resolve().parent.parent / "data" / "sample_logins.csv"


class SampleDatasetTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.parsed = parse_login_csv(SAMPLE.read_bytes())
        cls.alerts = analyze(cls.parsed.events)

    def find(self, rule_id, username=None, source=None):
        return [
            a
            for a in self.alerts
            if a.rule_id == rule_id
            and (username is None or a.usernames == (username,))
            and (source is None or source in a.source_ips)
        ]

    def test_file_is_clean_and_synthetic(self):
        self.assertEqual(self.parsed.skipped_rows, 0)
        self.assertGreater(len(self.parsed.events), 100)
        for event in self.parsed.events:
            external = not event.source_ip.startswith("10.")
            if external:
                self.assertTrue(
                    event.source_ip.startswith(("192.0.2.", "198.51.100.", "203.0.113.")),
                    f"{event.source_ip} is not a documentation-range address",
                )

    def test_exactly_the_planted_alerts_are_found(self):
        self.assertEqual(len(self.alerts), 6)
        brute = self.find(REPEATED_FAILURES, "svc_backup")
        self.assertEqual((len(brute), brute[0].severity, brute[0].event_count), (1, "high", 14))
        distributed = self.find(REPEATED_FAILURES, "admin")
        self.assertEqual((len(distributed), distributed[0].severity), (1, "medium"))
        self.assertEqual(len(distributed[0].source_ips), 6)
        self.assertEqual(self.find(REPEATED_FAILURES, "meera")[0].severity, "medium")
        self.assertEqual(self.find(SUCCESS_AFTER_FAILURES, "meera")[0].severity, "high")
        self.assertEqual(self.find(SUCCESS_AFTER_FAILURES, "rohan")[0].severity, "medium")
        spray = self.find(MULTI_ACCOUNT_FAILURES, source="198.51.100.77")
        self.assertEqual((len(spray), spray[0].severity, len(spray[0].usernames)), (1, "high", 10))
        self.assertEqual(self.find(UNUSUAL_TIME), [])  # off unless a schedule is configured

    def test_ordinary_users_are_not_reported_as_attackers(self):
        # These users only mistyped a password once or twice, or appear as spray targets.
        calm = {"aarav", "sneha", "vikram", "ananya", "kabir"}
        for alert in self.alerts:
            if alert.rule_id in (REPEATED_FAILURES, SUCCESS_AFTER_FAILURES):
                self.assertFalse(set(alert.usernames) & calm, alert.alert_id)

    def test_summary_numbers_match_the_data(self):
        summary = build_summary(self.parsed.events, self.alerts)
        self.assertEqual(summary.total_events, len(self.parsed.events))
        self.assertEqual(summary.alert_groups, 6)
        self.assertEqual(summary.flagged_events, 45)
        self.assertEqual(summary.severity_counts, {"high": 3, "medium": 3, "low": 0})
        self.assertEqual(summary.failed_logins + summary.successful_logins, summary.total_events)

    def test_unusual_time_rule_finds_the_late_night_logins_when_configured(self):
        config = DetectionConfig(schedule_start_hour=8, schedule_end_hour=18)
        alerts = [a for a in analyze(self.parsed.events, config) if a.rule_id == UNUSUAL_TIME]
        self.assertEqual(len(alerts), 2)
        self.assertTrue(all(a.usernames == ("vikram",) and a.severity == "low" for a in alerts))

    def test_timeline_accounts_for_every_event(self):
        flagged = flagged_lines(self.alerts)
        timeline = build_timeline(self.parsed.events, flagged)
        self.assertEqual(sum(b.total for b in timeline.buckets), len(self.parsed.events))
        self.assertEqual(sum(b.flagged for b in timeline.buckets), len(flagged))
        self.assertLessEqual(len(timeline.buckets), 48)


if __name__ == "__main__":
    unittest.main()
