"""Tests for the store, exporter helpers, filter parsing and chart geometry."""
import unittest
from datetime import datetime, timedelta

from logdecipher.analysis import build_analysis
from logdecipher.charts import nice_max, timeline_chart
from logdecipher.engine.config import DetectionConfig
from logdecipher.engine.detector import analyze
from logdecipher.engine.parser import ParseResult
from logdecipher.engine.summary import build_summary, build_timeline, describe_bucket_size
from logdecipher.exporter import alerts_to_csv, csv_safe
from logdecipher.filters import apply_filters, parse_filters
from logdecipher.store import AnalysisStore

from helpers import BASE, ev, failures


def make_analysis(label="test"):
    events = failures(5)
    parsed = ParseResult(events=events, issues=[], skipped_rows=0, total_rows=len(events))
    return build_analysis(parsed, analyze(events), DetectionConfig(), label)


class FakeClock:
    def __init__(self):
        self.now = 0.0

    def __call__(self):
        return self.now


class StoreTests(unittest.TestCase):
    def test_put_and_get(self):
        store = AnalysisStore()
        analysis = make_analysis()
        token = store.put(analysis)
        self.assertIs(store.get(token), analysis)
        self.assertIsNone(store.get("unknown"))
        self.assertIsNone(store.get(None))

    def test_tokens_are_unguessable_and_unique(self):
        store = AnalysisStore()
        tokens = {store.put(make_analysis()) for _ in range(5)}
        self.assertEqual(len(tokens), 5)
        self.assertTrue(all(len(t) >= 30 for t in tokens))

    def test_entries_expire(self):
        clock = FakeClock()
        store = AnalysisStore(ttl_seconds=60, clock=clock)
        token = store.put(make_analysis())
        clock.now = 59
        self.assertIsNotNone(store.get(token))
        clock.now = 59 + 61  # the earlier read refreshed the expiry; now it has lapsed
        self.assertIsNone(store.get(token))
        self.assertEqual(len(store), 0)

    def test_oldest_entry_is_evicted_when_full(self):
        store = AnalysisStore(max_items=2)
        first, second, third = (store.put(make_analysis(n)) for n in "abc")
        self.assertIsNone(store.get(first))
        self.assertIsNotNone(store.get(second))
        self.assertIsNotNone(store.get(third))

    def test_delete(self):
        store = AnalysisStore()
        token = store.put(make_analysis())
        store.delete(token)
        store.delete(token)  # deleting twice is harmless
        store.delete(None)
        self.assertIsNone(store.get(token))


class CsvSafeTests(unittest.TestCase):
    def test_dangerous_prefixes_are_neutralised(self):
        for value in ("=1+1", "+1", "-1", "@x", "\tx", "\rx", "\nx"):
            self.assertEqual(csv_safe(value), "'" + value)

    def test_ordinary_values_are_unchanged(self):
        for value in ("alice", "10.0.0.1", "2026-03-02 09:00:00 UTC", "a=b", "x-y", "", None):
            self.assertEqual(csv_safe(value), "" if value is None else value)

    def test_export_of_no_alerts_is_just_a_header(self):
        text = alerts_to_csv([])
        self.assertEqual(len(text.lstrip("﻿").strip().splitlines()), 1)

    def test_very_long_event_lists_are_truncated_in_the_cell(self):
        alerts = analyze(failures(400, step=1))
        row = alerts_to_csv(alerts)
        self.assertIn("(+200 more)", row)


class FilterParsingTests(unittest.TestCase):
    RULES = {"repeated_failures", "unusual_time"}

    def test_defaults(self):
        flt, errors = parse_filters({}, self.RULES)
        self.assertFalse(flt.is_active)
        self.assertEqual((flt.sort, errors, flt.query()), ("severity", [], {}))

    def test_valid_values_round_trip(self):
        flt, errors = parse_filters(
            {"severity": "HIGH", "rule": "unusual_time", "username": " Bob ", "source_ip": "10.", "time_from": "2026-03-02T09:00", "sort": "oldest"},
            self.RULES,
        )
        self.assertEqual(errors, [])
        self.assertEqual(flt.severity, "high")
        self.assertEqual(flt.username, "Bob")
        self.assertEqual(flt.time_from, datetime(2026, 3, 2, 9, 0))
        self.assertEqual(flt.query()["time_from"], "2026-03-02T09:00")
        self.assertEqual(flt.query()["sort"], "oldest")

    def test_invalid_values_are_dropped_and_reported(self):
        flt, errors = parse_filters({"severity": "x", "rule": "nope", "time_to": "soon", "sort": "random"}, self.RULES)
        self.assertEqual(len(errors), 3)
        self.assertFalse(flt.is_active)
        self.assertEqual(flt.sort, "severity")

    def test_text_filters_are_length_limited(self):
        flt, _ = parse_filters({"username": "a" * 1000}, self.RULES)
        self.assertEqual(len(flt.username), 128)

    def test_overlap_semantics(self):
        alerts = analyze(failures(5))  # 09:00:00 - 09:02:00
        inside, _ = parse_filters({"time_from": "2026-03-02T09:01", "time_to": "2026-03-02T09:03"}, self.RULES)
        before, _ = parse_filters({"time_to": "2026-03-02T08:59"}, self.RULES)
        after, _ = parse_filters({"time_from": "2026-03-02T09:03"}, self.RULES)
        self.assertEqual(len(apply_filters(alerts, inside)), 1)
        self.assertEqual(apply_filters(alerts, before), [])
        self.assertEqual(apply_filters(alerts, after), [])


class SummaryAndChartTests(unittest.TestCase):
    def test_summary_counts(self):
        events = failures(5) + [ev(10, BASE + timedelta(seconds=200), user="bob", ip="10.0.0.9", ok=True)]
        alerts = analyze(events)
        summary = build_summary(events, alerts)
        self.assertEqual(
            (summary.total_events, summary.failed_logins, summary.successful_logins),
            (6, 5, 1),
        )
        self.assertEqual((summary.unique_accounts, summary.unique_sources), (2, 2))
        self.assertEqual((summary.alert_groups, summary.flagged_events), (1, 5))
        self.assertEqual(summary.flagged_percent, 83.3)
        self.assertEqual(summary.severity_counts, {"high": 0, "medium": 1, "low": 0})

    def test_timeline_bucket_size_adapts_and_conserves_counts(self):
        short = failures(5)  # two minutes
        long = [ev(i + 1, BASE + timedelta(days=3, minutes=i * 30)) for i in range(200)]
        for events, max_minutes in ((short, 5), (long, 24 * 60)):
            timeline = build_timeline(events, set())
            self.assertEqual(sum(b.total for b in timeline.buckets), len(events))
            self.assertLessEqual(len(timeline.buckets), 48)
            self.assertLessEqual(timeline.bucket_minutes, max_minutes)

    def test_timeline_buckets_are_continuous(self):
        events = [ev(1, BASE), ev(2, BASE + timedelta(hours=5))]
        timeline = build_timeline(events, {1})
        starts = [b.start for b in timeline.buckets]
        steps = {b - a for a, b in zip(starts, starts[1:])}
        self.assertEqual(steps, {timedelta(minutes=timeline.bucket_minutes)})
        self.assertEqual(timeline.buckets[0].flagged, 1)

    def test_nice_max(self):
        self.assertEqual([nice_max(v) for v in (0, 1, 2, 3, 7, 12, 99, 101)], [1, 1, 2, 5, 10, 20, 100, 200])

    def test_chart_geometry_stays_inside_the_plot(self):
        events = [ev(i + 1, BASE + timedelta(minutes=i * 17), ok=i % 3 == 0) for i in range(60)]
        flagged = {1, 2, 3}
        chart = timeline_chart(build_timeline(events, flagged))
        for bar in chart["bars"]:
            self.assertGreaterEqual(bar["x"], chart["left"])
            self.assertLessEqual(bar["x"] + bar["width"], chart["plot_right"] + 0.01)
            self.assertLessEqual(bar["total_y"] + bar["total_height"], chart["plot_bottom"] + 0.01)
            self.assertLessEqual(bar["flagged_height"], bar["total_height"] + 0.01)

    def test_bucket_size_descriptions(self):
        self.assertEqual(describe_bucket_size(1), "1 minute")
        self.assertEqual(describe_bucket_size(30), "30 minutes")
        self.assertEqual(describe_bucket_size(60), "1 hour")
        self.assertEqual(describe_bucket_size(180), "3 hours")
        self.assertEqual(describe_bucket_size(1440), "1 day")


if __name__ == "__main__":
    unittest.main()
