import random
import unittest
from datetime import timedelta

from logdecipher.engine.config import ConfigError, DetectionConfig
from logdecipher.engine.detector import analyze
from logdecipher.engine.rules import (
    MULTI_ACCOUNT_FAILURES,
    REPEATED_FAILURES,
    SUCCESS_AFTER_FAILURES,
    UNUSUAL_TIME,
)
from logdecipher.engine.summary import build_summary

from helpers import BASE, ev, failures


def by_rule(alerts, rule_id):
    return [a for a in alerts if a.rule_id == rule_id]


class RepeatedFailuresTests(unittest.TestCase):
    def test_below_threshold_raises_no_alert(self):
        self.assertEqual(analyze(failures(4)), [])

    def test_threshold_raises_one_medium_alert_with_supporting_events(self):
        alerts = analyze(failures(5))
        self.assertEqual(len(alerts), 1)
        alert = alerts[0]
        self.assertEqual(alert.rule_id, REPEATED_FAILURES)
        self.assertEqual(alert.severity, "medium")
        self.assertEqual(alert.usernames, ("alice",))
        self.assertEqual(alert.event_lines, (1, 2, 3, 4, 5))
        self.assertEqual(alert.start, BASE)
        self.assertEqual(alert.end, BASE + timedelta(seconds=120))

    def test_twice_the_threshold_is_high(self):
        alerts = analyze(failures(10))
        self.assertEqual(alerts[0].severity, "high")

    def test_failures_spread_beyond_the_window_do_not_match(self):
        # 5 failures 3 minutes apart: any 10-minute window holds at most 4.
        self.assertEqual(analyze(failures(5, step=180)), [])

    def test_window_boundary_is_inclusive(self):
        # 5 failures exactly 10 minutes from first to last.
        self.assertEqual(len(analyze(failures(5, step=150))), 1)

    def test_successes_are_not_counted_as_failures(self):
        events = failures(4) + [ev(10, BASE + timedelta(seconds=45), ok=True)]
        self.assertEqual(by_rule(analyze(events), REPEATED_FAILURES), [])

    def test_accounts_are_counted_independently(self):
        events = failures(3, user="alice") + failures(3, user="bob", first_line=10)
        self.assertEqual(by_rule(analyze(events), REPEATED_FAILURES), [])

    def test_failures_from_several_sources_are_combined_per_account(self):
        events = [
            ev(i + 1, BASE + timedelta(seconds=20 * i), ip=f"192.0.2.{i + 1}") for i in range(5)
        ]
        alerts = by_rule(analyze(events), REPEATED_FAILURES)
        self.assertEqual(len(alerts), 1)
        self.assertEqual(len(alerts[0].source_ips), 5)

    def test_separate_bursts_make_separate_alerts(self):
        later = BASE + timedelta(hours=2)
        events = failures(5) + failures(5, start=later, first_line=10)
        self.assertEqual(len(by_rule(analyze(events), REPEATED_FAILURES)), 2)

    def test_one_long_burst_is_merged_into_one_alert(self):
        alerts = analyze(failures(12, step=60))  # spans 11 minutes, overlapping windows
        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0].event_count, 12)

    def test_custom_threshold_and_window_are_respected(self):
        config = DetectionConfig(failure_threshold=3, window_minutes=1)
        self.assertEqual(len(analyze(failures(3, step=20), config)), 1)
        self.assertEqual(analyze(failures(3, step=40), config), [])  # 80 s apart > 1 minute


class SuccessAfterFailuresTests(unittest.TestCase):
    def success_at(self, line, seconds, **kwargs):
        return ev(line, BASE + timedelta(seconds=seconds), ok=True, **kwargs)

    def test_success_after_threshold_failures_is_flagged(self):
        events = failures(3) + [self.success_at(10, 100)]
        alerts = by_rule(analyze(events), SUCCESS_AFTER_FAILURES)
        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0].severity, "medium")
        self.assertEqual(alerts[0].event_count, 4)
        self.assertEqual(alerts[0].event_lines[-1], 10)

    def test_too_few_failures_is_not_flagged(self):
        events = failures(2) + [self.success_at(10, 100)]
        self.assertEqual(by_rule(analyze(events), SUCCESS_AFTER_FAILURES), [])

    def test_failures_older_than_the_window_do_not_count(self):
        events = failures(3) + [self.success_at(10, 15 * 60)]
        self.assertEqual(by_rule(analyze(events), SUCCESS_AFTER_FAILURES), [])

    def test_a_success_resets_the_failure_count(self):
        events = failures(3) + [self.success_at(10, 100), self.success_at(11, 130)]
        self.assertEqual(len(by_rule(analyze(events), SUCCESS_AFTER_FAILURES)), 1)

    def test_failures_before_an_earlier_success_are_not_reused(self):
        events = (
            failures(2)
            + [self.success_at(10, 70)]
            + failures(2, start=BASE + timedelta(seconds=80), first_line=20)
            + [self.success_at(11, 160)]
        )
        self.assertEqual(by_rule(analyze(events), SUCCESS_AFTER_FAILURES), [])

    def test_many_failures_before_success_is_high(self):
        events = failures(6) + [self.success_at(10, 200)]
        alerts = by_rule(analyze(events), SUCCESS_AFTER_FAILURES)
        self.assertEqual(alerts[0].severity, "high")

    def test_other_accounts_failures_do_not_count(self):
        events = failures(3, user="bob", first_line=20) + [self.success_at(10, 100)]
        self.assertEqual(by_rule(analyze(events), SUCCESS_AFTER_FAILURES), [])

    def test_explanation_states_whether_the_success_came_from_a_failing_address(self):
        same = analyze(failures(3, ip="192.0.2.5") + [self.success_at(10, 100, ip="192.0.2.5")])
        different = analyze(failures(3, ip="192.0.2.5") + [self.success_at(10, 100, ip="198.51.100.9")])
        self.assertIn("is one of those addresses", by_rule(same, SUCCESS_AFTER_FAILURES)[0].explanation)
        self.assertIn(
            "is not one of those addresses", by_rule(different, SUCCESS_AFTER_FAILURES)[0].explanation
        )


class MultiAccountFailuresTests(unittest.TestCase):
    def spray(self, accounts, step=30, ip="198.51.100.7", start=BASE):
        return [
            ev(i + 1, start + timedelta(seconds=step * i), user=f"user{i}", ip=ip)
            for i in range(accounts)
        ]

    def test_four_accounts_from_one_source_is_flagged(self):
        alerts = by_rule(analyze(self.spray(4)), MULTI_ACCOUNT_FAILURES)
        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0].severity, "medium")
        self.assertEqual(len(alerts[0].usernames), 4)
        self.assertEqual(alerts[0].source_ips, ("198.51.100.7",))

    def test_three_accounts_is_not_flagged(self):
        self.assertEqual(analyze(self.spray(3)), [])

    def test_accounts_spread_beyond_the_window_are_not_flagged(self):
        self.assertEqual(analyze(self.spray(4, step=600)), [])  # at most 2 per 10 minutes

    def test_twice_the_threshold_is_high(self):
        alerts = by_rule(analyze(self.spray(8)), MULTI_ACCOUNT_FAILURES)
        self.assertEqual(alerts[0].severity, "high")

    def test_different_sources_each_hitting_one_account_is_not_a_spray(self):
        events = [
            ev(i + 1, BASE + timedelta(seconds=30 * i), user=f"user{i}", ip=f"192.0.2.{i + 1}")
            for i in range(6)
        ]
        self.assertEqual(by_rule(analyze(events), MULTI_ACCOUNT_FAILURES), [])

    def test_spray_with_one_failure_per_account_does_not_trigger_the_per_account_rule(self):
        alerts = analyze(self.spray(6))
        self.assertEqual(by_rule(alerts, REPEATED_FAILURES), [])
        self.assertEqual(len(by_rule(alerts, MULTI_ACCOUNT_FAILURES)), 1)


class UnusualTimeTests(unittest.TestCase):
    def login(self, line, when, user="alice", ok=True):
        return ev(line, when, user=user, ok=ok)

    def test_rule_is_off_without_a_configured_schedule(self):
        self.assertEqual(analyze([self.login(1, "2026-03-02 03:00:00")]), [])

    def test_login_outside_schedule_is_low_severity(self):
        config = DetectionConfig(schedule_start_hour=8, schedule_end_hour=18)
        alerts = analyze([self.login(1, "2026-03-02 03:00:00")], config)
        self.assertEqual(len(alerts), 1)
        self.assertEqual(alerts[0].rule_id, UNUSUAL_TIME)
        self.assertEqual(alerts[0].severity, "low")

    def test_login_inside_schedule_is_not_flagged(self):
        config = DetectionConfig(schedule_start_hour=8, schedule_end_hour=18)
        self.assertEqual(analyze([self.login(1, "2026-03-02 10:00:00")], config), [])

    def test_failures_are_not_checked(self):
        config = DetectionConfig(schedule_start_hour=8, schedule_end_hour=18)
        self.assertEqual(analyze([self.login(1, "2026-03-02 03:00:00", ok=False)], config), [])

    def test_start_hour_is_included_and_end_hour_is_excluded(self):
        config = DetectionConfig(schedule_start_hour=8, schedule_end_hour=18)
        events = [self.login(1, "2026-03-02 08:00:00"), self.login(2, "2026-03-02 18:00:00")]
        alerts = analyze(events, config)
        self.assertEqual([a.event_lines for a in alerts], [(2,)])

    def test_schedule_that_crosses_midnight(self):
        config = DetectionConfig(schedule_start_hour=22, schedule_end_hour=6)
        events = [
            self.login(1, "2026-03-02 23:00:00"),
            self.login(2, "2026-03-03 03:00:00"),
            self.login(3, "2026-03-03 12:00:00"),
        ]
        alerts = analyze(events, config)
        self.assertEqual([a.event_lines for a in alerts], [(3,)])

    def test_grouped_per_account_and_day(self):
        config = DetectionConfig(schedule_start_hour=8, schedule_end_hour=18)
        events = [
            self.login(1, "2026-03-02 02:00:00"),
            self.login(2, "2026-03-02 23:00:00"),
            self.login(3, "2026-03-03 02:00:00"),
            self.login(4, "2026-03-02 02:30:00", user="bob"),
        ]
        alerts = analyze(events, config)
        self.assertEqual(len(alerts), 3)
        self.assertEqual(sorted(a.event_count for a in alerts), [1, 1, 2])


class EngineBehaviourTests(unittest.TestCase):
    def test_normal_activity_produces_no_alerts(self):
        events = []
        line = 1
        for minute in range(0, 600, 7):
            events.append(ev(line, BASE + timedelta(minutes=minute), user=f"user{minute % 5}", ok=True))
            line += 1
        # Occasional single typos, always followed by a success.
        for minute in (50, 200, 410):
            events.append(ev(line, BASE + timedelta(minutes=minute, seconds=5), user="user1"))
            line += 1
        self.assertEqual(analyze(events), [])

    def test_alert_ids_are_sequential_and_unique(self):
        events = failures(5) + failures(5, user="bob", start=BASE + timedelta(hours=3), first_line=20)
        ids = [a.alert_id for a in analyze(events)]
        self.assertEqual(ids, ["LD-0001", "LD-0002"])

    def test_results_do_not_depend_on_input_order(self):
        events = failures(6) + [ev(50, BASE + timedelta(seconds=200), ok=True)]
        events += [
            ev(100 + i, BASE + timedelta(hours=1, seconds=20 * i), user=f"u{i}", ip="198.51.100.9")
            for i in range(5)
        ]
        shuffled = events[:]
        random.Random(1).shuffle(shuffled)
        self.assertEqual(analyze(events), analyze(shuffled))

    def test_overlapping_alerts_share_events_but_flagged_events_are_counted_once(self):
        events = failures(5) + [ev(10, BASE + timedelta(seconds=150), ok=True)]
        alerts = analyze(events)
        self.assertEqual(
            sorted(a.rule_id for a in alerts), [REPEATED_FAILURES, SUCCESS_AFTER_FAILURES]
        )
        summary = build_summary(events, alerts)
        self.assertEqual(summary.alert_groups, 2)
        self.assertEqual(summary.flagged_events, 6)  # 5 failures + 1 success, not 5 + 6

    def test_every_alert_is_fully_explained_and_never_claims_proof(self):
        events = failures(6) + [ev(50, BASE + timedelta(seconds=200), ok=True)]
        events += [
            ev(100 + i, BASE + timedelta(hours=1, seconds=20 * i), user=f"u{i}", ip="198.51.100.9")
            for i in range(5)
        ]
        alerts = analyze(events, DetectionConfig(schedule_start_hour=10, schedule_end_hour=11))
        self.assertGreaterEqual(len(alerts), 3)
        for alert in alerts:
            for text in (alert.explanation, alert.recommendation, alert.limitations):
                self.assertTrue(text.strip())
            combined = (alert.explanation + alert.limitations).lower()
            self.assertNotIn("confirmed attack", combined)
            self.assertNotIn("is malicious", combined)
            self.assertTrue(alert.alert_id.startswith("LD-"))

    def test_empty_input_gives_no_alerts(self):
        self.assertEqual(analyze([]), [])


class ConfigValidationTests(unittest.TestCase):
    def assert_invalid(self, **kwargs):
        with self.assertRaises(ConfigError):
            DetectionConfig(**kwargs).validate()

    def test_defaults_are_valid(self):
        DetectionConfig().validate()

    def test_out_of_range_values_are_rejected(self):
        self.assert_invalid(window_minutes=0)
        self.assert_invalid(window_minutes=1441)
        self.assert_invalid(failure_threshold=1)
        self.assert_invalid(success_after_failures_threshold=1)
        self.assert_invalid(spray_account_threshold=1)

    def test_wrong_types_are_rejected(self):
        self.assert_invalid(window_minutes=True)
        self.assert_invalid(failure_threshold="5")

    def test_schedule_must_be_complete_and_sensible(self):
        self.assert_invalid(schedule_start_hour=8)
        self.assert_invalid(schedule_end_hour=18)
        self.assert_invalid(schedule_start_hour=8, schedule_end_hour=8)
        self.assert_invalid(schedule_start_hour=24, schedule_end_hour=5)
        self.assert_invalid(schedule_start_hour=-1, schedule_end_hour=5)

    def test_analyze_validates_the_configuration(self):
        with self.assertRaises(ConfigError):
            analyze([], DetectionConfig(window_minutes=0))


if __name__ == "__main__":
    unittest.main()
