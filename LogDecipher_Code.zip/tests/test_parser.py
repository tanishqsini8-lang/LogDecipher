import unittest
from datetime import datetime

from logdecipher.engine.parser import (
    CsvValidationError,
    parse_login_csv,
    parse_timestamp,
)

HEADER = "timestamp,username,source_ip,status\n"


def csv_bytes(body: str, header: str = HEADER) -> bytes:
    return (header + body).encode("utf-8")


class ValidFileTests(unittest.TestCase):
    def test_valid_file_is_parsed(self):
        result = parse_login_csv(
            csv_bytes(
                "2026-03-02 09:14:05,Alice,10.0.0.1,success\n"
                "2026-03-02 09:15:00,bob,203.0.113.7,failure\n"
            )
        )
        self.assertEqual(len(result.events), 2)
        self.assertEqual(result.skipped_rows, 0)
        first = result.events[0]
        self.assertEqual(first.username, "alice")  # usernames are compared case-insensitively
        self.assertEqual(first.timestamp, datetime(2026, 3, 2, 9, 14, 5))
        self.assertTrue(first.success)
        self.assertFalse(result.events[1].success)
        self.assertEqual(first.line, 2)  # line numbers refer to the uploaded file

    def test_header_is_case_and_space_insensitive_and_extra_columns_are_ignored(self):
        data = (
            " Timestamp , USERNAME,source_ip,status,password\n"
            "2026-03-02T09:14:05,alice,10.0.0.1,SUCCESS,hunter2\n"
        ).encode()
        result = parse_login_csv(data)
        self.assertEqual(len(result.events), 1)
        self.assertFalse(hasattr(result.events[0], "password"))

    def test_columns_may_appear_in_any_order(self):
        data = "status,source_ip,username,timestamp\nfailed,10.0.0.1,alice,2026-03-02 09:14:05\n".encode()
        event = parse_login_csv(data).events[0]
        self.assertFalse(event.success)
        self.assertEqual(event.username, "alice")

    def test_utf8_bom_and_windows_line_endings(self):
        data = ("﻿" + HEADER + "2026-03-02 09:14:05,alice,10.0.0.1,success\n").replace("\n", "\r\n").encode()
        self.assertEqual(len(parse_login_csv(data).events), 1)

    def test_timezone_aware_timestamps_are_converted_to_utc(self):
        result = parse_login_csv(
            csv_bytes(
                "2026-03-02T10:00:00+05:30,alice,10.0.0.1,success\n"
                "2026-03-02T04:30:00Z,bob,10.0.0.2,success\n"
            )
        )
        self.assertEqual(result.events[0].timestamp, datetime(2026, 3, 2, 4, 30, 0))
        self.assertEqual(result.events[1].timestamp, datetime(2026, 3, 2, 4, 30, 0))

    def test_ipv6_addresses_are_accepted_and_normalised(self):
        event = parse_login_csv(csv_bytes("2026-03-02 09:00:00,alice,2001:DB8:0:0:0:0:0:1,success\n")).events[0]
        self.assertEqual(event.source_ip, "2001:db8::1")

    def test_blank_lines_are_ignored(self):
        data = csv_bytes("\n2026-03-02 09:00:00,alice,10.0.0.1,success\n\n\n")
        result = parse_login_csv(data)
        self.assertEqual(len(result.events), 1)
        self.assertEqual(result.skipped_rows, 0)

    def test_status_synonyms(self):
        rows = "".join(
            f"2026-03-02 09:00:0{i},u{i},10.0.0.1,{status}\n"
            for i, status in enumerate(["ok", "Accepted", "denied", "FAIL"])
        )
        statuses = [e.success for e in parse_login_csv(csv_bytes(rows)).events]
        self.assertEqual(statuses, [True, True, False, False])

    def test_formula_like_usernames_are_kept_as_plain_text(self):
        event = parse_login_csv(csv_bytes('2026-03-02 09:00:00,"=1+1",10.0.0.1,failure\n')).events[0]
        self.assertEqual(event.username, "=1+1")


class RowProblemTests(unittest.TestCase):
    def test_bad_rows_are_skipped_and_reported_without_losing_good_rows(self):
        result = parse_login_csv(
            csv_bytes(
                "2026-03-02 09:00:00,alice,10.0.0.1,success\n"
                "not-a-time,bob,10.0.0.2,success\n"
                "2026-03-02 09:02:00,carol,999.0.0.1,success\n"
                "2026-03-02 09:03:00,dave,10.0.0.4,maybe\n"
                "2026-03-02 09:04:00,,10.0.0.5,success\n"
                "2026-03-02 09:05:00,erin,10.0.0.6\n"
                "2026-03-02 09:06:00,frank,10.0.0.7,failure\n"
            )
        )
        self.assertEqual([e.username for e in result.events], ["alice", "frank"])
        self.assertEqual(result.skipped_rows, 5)
        self.assertEqual([i.line for i in result.issues], [3, 4, 5, 6, 7])
        messages = " | ".join(i.message for i in result.issues)
        for expected in ("timestamp", "IP address", "status", "missing username", "fields"):
            self.assertIn(expected, messages)

    def test_issue_messages_do_not_echo_file_content(self):
        result = parse_login_csv(
            csv_bytes(
                "2026-03-02 09:00:00,alice,10.0.0.1,success\n"
                "<script>alert(1)</script>,bob,10.0.0.2,success\n"
            )
        )
        self.assertNotIn("<script>", " ".join(i.message for i in result.issues))

    def test_date_without_time_is_rejected(self):
        self.assertIsNone(parse_timestamp("2026-03-02"))

    def test_unreasonable_years_are_rejected(self):
        self.assertIsNone(parse_timestamp("1850-01-01 00:00:00"))
        self.assertIsNone(parse_timestamp("9999-01-01 00:00:00"))

    def test_overlong_or_control_character_usernames_are_rejected(self):
        long_name = "a" * 129
        result = parse_login_csv(
            csv_bytes(
                "2026-03-02 09:00:00,alice,10.0.0.1,success\n"
                f"2026-03-02 09:01:00,{long_name},10.0.0.1,success\n"
                '2026-03-02 09:02:00,"bad\x07name",10.0.0.1,success\n'
            )
        )
        self.assertEqual(len(result.events), 1)
        self.assertEqual(result.skipped_rows, 2)

    def test_issue_list_is_capped_but_the_skipped_count_is_exact(self):
        rows = "2026-03-02 09:00:00,alice,10.0.0.1,success\n" + "bad,bob,10.0.0.2,success\n" * 150
        result = parse_login_csv(csv_bytes(rows), max_issues=100)
        self.assertEqual(result.skipped_rows, 150)
        self.assertEqual(len(result.issues), 100)
        self.assertTrue(result.issues_truncated)


class FileLevelProblemTests(unittest.TestCase):
    def assert_rejected(self, data, fragment, **kwargs):
        with self.assertRaises(CsvValidationError) as ctx:
            parse_login_csv(data, **kwargs)
        self.assertIn(fragment, str(ctx.exception))

    def test_empty_file(self):
        self.assert_rejected(b"", "empty")

    def test_whitespace_only_file(self):
        self.assert_rejected(b"  \n \n", "no data")

    def test_header_only_file(self):
        self.assert_rejected(HEADER.encode(), "no login events")

    def test_missing_columns_are_named(self):
        self.assert_rejected(b"timestamp,username\n2026-03-02 09:00:00,alice\n", "source_ip, status")

    def test_duplicate_required_column(self):
        self.assert_rejected(
            b"timestamp,username,username,source_ip,status\n", "more than once"
        )

    def test_file_over_the_size_limit(self):
        data = csv_bytes("2026-03-02 09:00:00,alice,10.0.0.1,success\n" * 50)
        self.assert_rejected(data, "larger than", max_bytes=500)

    def test_too_many_rows(self):
        data = csv_bytes("2026-03-02 09:00:00,alice,10.0.0.1,success\n" * 11)
        self.assert_rejected(data, "more than 10 rows", max_rows=10)

    def test_binary_content(self):
        self.assert_rejected(b"\x89PNG\r\n\x1a\n\x00\x00\x00", "binary")

    def test_non_utf8_text(self):
        self.assert_rejected(HEADER.encode() + "2026-03-02 09:00:00,José,10.0.0.1,success\n".encode("latin-1"), "UTF-8")

    def test_unbalanced_quotes(self):
        self.assert_rejected(csv_bytes('2026-03-02 09:00:00,"alice,10.0.0.1,success\n'), "No valid")

    def test_all_rows_invalid_reports_the_first_problem(self):
        self.assert_rejected(csv_bytes("nope,alice,10.0.0.1,success\n"), "First problem: line 2")


if __name__ == "__main__":
    unittest.main()
