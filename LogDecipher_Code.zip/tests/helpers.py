"""Shared helpers for building synthetic login events in tests."""
from datetime import datetime, timedelta
from typing import List

from logdecipher.engine.models import LoginEvent

BASE = datetime(2026, 3, 2, 9, 0, 0)


def ev(line: int, when, user: str = "alice", ip: str = "10.0.0.1", ok: bool = False) -> LoginEvent:
    moment = datetime.fromisoformat(when) if isinstance(when, str) else when
    return LoginEvent(line=line, timestamp=moment, username=user, source_ip=ip, success=ok)


def failures(
    count: int,
    user: str = "alice",
    ip: str = "10.0.0.1",
    start: datetime = BASE,
    step: int = 30,
    first_line: int = 1,
) -> List[LoginEvent]:
    """``count`` failed logins, ``step`` seconds apart."""
    return [
        ev(first_line + i, start + timedelta(seconds=step * i), user, ip, False) for i in range(count)
    ]
