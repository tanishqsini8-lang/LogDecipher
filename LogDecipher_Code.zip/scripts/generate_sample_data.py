#!/usr/bin/env python3
"""Generate the fictional LogDecipher sample dataset (data/sample_logins.csv).

Everything here is invented: the user names, the internal 10.x.x.x addresses, and the
"external" addresses, which come from the ranges reserved for documentation by RFC 5737
(192.0.2.0/24, 198.51.100.0/24, 203.0.113.0/24). No real people or networks are involved.

The output is deterministic (fixed random seed), so re-running the script reproduces the
committed file. The scenarios below are planted on purpose so each detection rule has
something to find, plus ordinary traffic that must NOT be reported.
"""
from __future__ import annotations

import csv
import random
from datetime import datetime, timedelta
from pathlib import Path

OUTPUT = Path(__file__).resolve().parent.parent / "data" / "sample_logins.csv"
rng = random.Random(20260302)

DAYS = [datetime(2026, 3, 2), datetime(2026, 3, 3)]
REGULAR_USERS = {
    "aarav": "10.0.1.11",
    "meera": "10.0.2.14",
    "rohan": "10.0.4.21",
    "sneha": "10.0.3.8",
    "vikram": "10.0.4.30",
    "ananya": "10.0.2.27",
    "kabir": "10.0.3.19",
}

events = []  # (timestamp, username, source_ip, status)


def add(moment: datetime, user: str, ip: str, ok: bool) -> None:
    events.append((moment, user, ip, "success" if ok else "failure"))


def at(day: int, hhmmss: str) -> datetime:
    hours, minutes, seconds = (int(part) for part in hhmmss.split(":"))
    return DAYS[day] + timedelta(hours=hours, minutes=minutes, seconds=seconds)


# --- Planted scenarios ------------------------------------------------------------------
# Scenario 1 (rule: repeated failures, HIGH): 14 failures against a service account.
start = at(0, "13:05:00")
for i in range(14):
    add(start + timedelta(seconds=26 * i), "svc_backup", "203.0.113.45", False)

# Scenario 2 (rule: success after failures, MEDIUM): a user mistypes a password 3 times.
# This is deliberately ordinary behaviour, to show why the rule has false positives.
start = at(0, "10:14:02")
for i, offset in enumerate((0, 18, 39)):
    add(start + timedelta(seconds=offset), "rohan", "10.0.4.21", False)
add(at(0, "10:15:10"), "rohan", "10.0.4.21", True)

# Scenario 3 (rule: failures across accounts, HIGH): one address tries ten account names.
spray_ip = "198.51.100.77"
spray_names = ["admin", "root", "aarav", "meera", "rohan", "sneha", "vikram", "ananya", "test", "guest"]
start = at(0, "15:40:00")
for i, name in enumerate(spray_names):
    add(start + timedelta(seconds=40 * i), name, spray_ip, False)
add(at(0, "15:46:30"), "admin", spray_ip, False)
add(at(0, "15:47:10"), "root", spray_ip, False)

# Scenario 4 (rule: unusual time, LOW, only when a schedule is configured).
add(at(0, "22:50:12"), "vikram", "10.0.4.30", True)
add(at(1, "02:41:37"), "vikram", "10.0.4.30", True)

# Scenario 5 (rules: repeated failures MEDIUM + success after failures HIGH): eight failures
# against one account from an outside address, then a success from the same address.
start = at(1, "09:20:00")
for i in range(8):
    add(start + timedelta(seconds=55 * i), "meera", "192.0.2.88", False)
add(at(1, "09:28:30"), "meera", "192.0.2.88", True)

# Scenario 6 (rule: repeated failures, MEDIUM): six different addresses each try "admin" once.
# Each address fails only once, so the multi-account rule stays quiet; the account-level rule sees it.
distributed_ips = ["192.0.2.10", "192.0.2.11", "198.51.100.5", "198.51.100.6", "203.0.113.9", "203.0.113.10"]
start = at(1, "14:00:00")
for i, ip in enumerate(distributed_ips):
    add(start + timedelta(seconds=80 * i), "admin", ip, False)

# --- Ordinary traffic that must not be reported -----------------------------------------
# Windows around planted scenarios where we keep ordinary logins for the same account away,
# so a normal success does not interrupt a planted run of failures.
QUIET = [
    ("rohan", at(0, "10:00:00"), at(0, "10:30:00")),
    ("meera", at(1, "09:05:00"), at(1, "09:45:00")),
    ("svc_backup", at(0, "12:50:00"), at(0, "13:30:00")),
    ("admin", at(1, "13:45:00"), at(1, "14:30:00")),
    ("admin", at(0, "15:25:00"), at(0, "16:00:00")),
]


def allowed(user: str, moment: datetime) -> bool:
    return not any(u == user and lo <= moment <= hi for u, lo, hi in QUIET)


for day in DAYS:
    for user, ip in REGULAR_USERS.items():
        for _ in range(rng.randint(2, 4)):
            moment = day + timedelta(hours=8, seconds=rng.randint(0, 10 * 3600 - 1))
            if allowed(user, moment):
                add(moment, user, ip, True)

# Service and admin accounts log in on a regular, in-hours pattern.
for day in range(2):
    add(at(day, "09:00:04"), "svc_backup", "10.0.9.5", True)
    add(at(day, "15:00:09"), "svc_backup", "10.0.9.5", True)
add(at(0, "11:05:21"), "admin", "10.0.1.10", True)
add(at(1, "16:20:48"), "admin", "10.0.1.10", True)

# A handful of single typos: one failure, then the correct password a few seconds later.
for _ in range(8):
    user = rng.choice(list(REGULAR_USERS))
    moment = rng.choice(DAYS) + timedelta(hours=8, seconds=rng.randint(0, 9 * 3600))
    if allowed(user, moment) and allowed(user, moment + timedelta(minutes=2)):
        add(moment, user, REGULAR_USERS[user], False)
        add(moment + timedelta(seconds=rng.randint(12, 40)), user, REGULAR_USERS[user], True)

events.sort(key=lambda row: (row[0], row[1], row[3]))

OUTPUT.parent.mkdir(parents=True, exist_ok=True)
with OUTPUT.open("w", newline="", encoding="utf-8") as handle:
    writer = csv.writer(handle, lineterminator="\n")
    writer.writerow(["timestamp", "username", "source_ip", "status"])
    for moment, user, ip, status in events:
        writer.writerow([moment.strftime("%Y-%m-%d %H:%M:%S"), user, ip, status])

print(f"Wrote {len(events)} events to {OUTPUT}")
