#!/usr/bin/env python3
"""Build LogDecipher_Project_Report.pdf from the real implementation (needs reportlab)."""
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from PIL import Image as PILImage
from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import (Image, KeepTogether, PageBreak, Paragraph, Preformatted,
                                SimpleDocTemplate, Spacer, Table, TableStyle)
from reportlab.graphics.shapes import Drawing, Rect, String, Line

from logdecipher.engine.config import DetectionConfig
from logdecipher.engine.detector import analyze
from logdecipher.engine.parser import parse_login_csv
from logdecipher.engine.summary import build_summary

OUT = ROOT / "LogDecipher_Project_Report.pdf"
SHOTS = ROOT / "docs" / "screenshots"

parsed = parse_login_csv((ROOT / "data" / "sample_logins.csv").read_bytes())
alerts = analyze(parsed.events)
summary = build_summary(parsed.events, alerts)
alerts_sched = analyze(parsed.events, DetectionConfig(schedule_start_hour=8, schedule_end_hour=18))

ss = getSampleStyleSheet()
BODY = ParagraphStyle("body", parent=ss["BodyText"], fontName="Helvetica", fontSize=10.5, leading=15, spaceAfter=7)
H1 = ParagraphStyle("h1", parent=ss["Heading1"], fontName="Helvetica-Bold", fontSize=17, spaceBefore=6, spaceAfter=10, textColor=colors.HexColor("#0e1319"))
H2 = ParagraphStyle("h2", parent=ss["Heading2"], fontName="Helvetica-Bold", fontSize=12.5, spaceBefore=10, spaceAfter=6, textColor=colors.HexColor("#1f4f48"))
BUL = ParagraphStyle("bul", parent=BODY, leftIndent=16, bulletIndent=4, spaceAfter=3)
CAP = ParagraphStyle("cap", parent=BODY, fontSize=9, leading=12, textColor=colors.HexColor("#555555"), alignment=TA_CENTER)
CELL = ParagraphStyle("cell", parent=BODY, fontSize=8.8, leading=11.5, spaceAfter=0)
CELLB = ParagraphStyle("cellb", parent=CELL, fontName="Helvetica-Bold")
CODE = ParagraphStyle("code", fontName="Courier", fontSize=8.5, leading=11)
TITLE = ParagraphStyle("title", parent=H1, fontSize=28, leading=34, alignment=TA_CENTER, spaceAfter=6)
SUB = ParagraphStyle("sub", parent=BODY, fontSize=14, leading=19, alignment=TA_CENTER, textColor=colors.HexColor("#333333"))
CTR = ParagraphStyle("ctr", parent=BODY, alignment=TA_CENTER)


def P(t, s=BODY): return Paragraph(t, s)
def B(items): return [Paragraph(i, BUL, bulletText="•") for i in items]


def table(rows, widths, header=True):
    data = [[Paragraph(str(c), CELLB if (header and r == 0) else CELL) for c in row] for r, row in enumerate(rows)]
    t = Table(data, colWidths=widths, repeatRows=1 if header else 0)
    style = [("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#b8c0cc")),
             ("VALIGN", (0, 0), (-1, -1), "TOP"),
             ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4)]
    if header:
        style.append(("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dfe8e6")))
    t.setStyle(TableStyle(style))
    return t


def shot(name, caption, width=15.5 * cm, max_h=15 * cm):
    w, h = PILImage.open(SHOTS / name).size
    scale = min(width / w, max_h / h)
    img = Image(str(SHOTS / name), width=w * scale, height=h * scale)
    img.hAlign = "CENTER"
    return KeepTogether([img, Spacer(1, 3), P(caption, CAP), Spacer(1, 8)])


def architecture():
    d = Drawing(16 * cm, 6.4 * cm)
    def box(x, y, w, h, text, fill):
        d.add(Rect(x, y, w, h, rx=5, ry=5, fillColor=colors.HexColor(fill), strokeColor=colors.HexColor("#456"), strokeWidth=0.8))
        lines = text.split("\n")
        for i, line in enumerate(lines):
            d.add(String(x + w / 2, y + h / 2 + (len(lines) / 2 - i - 0.8) * 10, line, textAnchor="middle", fontName="Helvetica-Bold" if i == 0 else "Helvetica", fontSize=8))
    def arrow(x1, y1, x2, y2):
        d.add(Line(x1, y1, x2, y2, strokeColor=colors.HexColor("#456"), strokeWidth=1))
        d.add(Line(x2, y2, x2 - 4 * (1 if x2 > x1 else -1 if x2 < x1 else 0), y2 + (4 if y2 < y1 else -4 if y2 > y1 else 3), strokeColor=colors.HexColor("#456"), strokeWidth=1))
    box(0, 120, 100, 50, "Browser\nupload, filters, export", "#e8f1ff")
    box(130, 120, 130, 50, "Flask app (app.py)\nroutes, CSRF, headers", "#dff3ef")
    box(290, 120, 150, 50, "Parser (parser.py)\nvalidates CSV rows", "#fff1d6")
    box(290, 40, 150, 50, "Detector (detector.py)\n4 rules -> alerts", "#fde4e4")
    box(130, 40, 130, 50, "Summary + charts\nmetrics, SVG timeline", "#ece6fb")
    box(0, 40, 100, 50, "Exporter\nsafe CSV output", "#e6f4e6")
    arrow(100, 145, 130, 145); arrow(260, 145, 290, 145); arrow(365, 120, 365, 90)
    arrow(290, 65, 260, 65); arrow(130, 65, 100, 65)
    d.add(String(0, 12, "Data flow: file -> validated events -> alerts -> dashboard / export. Results are held in memory only.", fontName="Helvetica-Oblique", fontSize=8))
    return d


def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont("Helvetica", 8.5)
    canvas.setFillColor(colors.HexColor("#666666"))
    canvas.drawString(2 * cm, 1.1 * cm, "LogDecipher — Explainable Cybersecurity Log Analysis Platform")
    canvas.drawRightString(A4[0] - 2 * cm, 1.1 * cm, f"Page {doc.page}")
    canvas.restoreState()


s = []
# ---------------------------------------------------------------- title page
s += [Spacer(1, 5 * cm), P("LogDecipher", TITLE),
      P("Explainable Cybersecurity Log Analysis Platform", SUB), Spacer(1, 1.2 * cm),
      P("Project Report", SUB), Spacer(1, 3 * cm),
      P("Submitted by: <b>Tanishq Saini</b>", CTR),
      P("First-year student, Cybersecurity and Blockchain", CTR), Spacer(1, 0.6 * cm),
      P("October 2026", CTR), Spacer(1, 4 * cm),
      P("<i>An independent educational project. It is not an IBM product and not a production-grade SIEM.</i>", CTR),
      PageBreak()]

# ---------------------------------------------------------------- abstract
s += [P("1. Abstract", H1),
      P("LogDecipher is a web application that analyzes login-event CSV files, identifies suspicious activity with simple, understandable detection rules, and explains why each finding deserves investigation. It is written in Python with the Flask framework and a plain HTML, CSS and JavaScript interface, and needs no database or paid service."),
      P("A user uploads a file with four columns (timestamp, username, source IP address, status). LogDecipher validates the file, applies four threshold-based rules, and shows a dashboard with metrics, a severity chart, an event timeline, and a filterable list of alerts. Each alert has its own page showing the supporting events, the reason the rule matched, a recommended defensive action, and the rule's limitations and possible false positives. Findings can be exported as a CSV file that is protected against spreadsheet formula injection."),
      P("The project demonstrates fundamental Security Information and Event Management (SIEM) ideas: log ingestion and validation, rule-based detection, alert triage, and explainability. The implementation was checked with 150 automated tests and 25 browser-driven checks, whose real results are reported in Section 8."),
      P("2. Objectives", H1)]
s += B(["Build a working application that finds repeated failed logins and related suspicious login patterns in a CSV file.",
        "Explain every alert in plain language, including what to do next and why it might be a false positive.",
        "Handle invalid, empty, oversized and hostile input safely.",
        "Calculate every displayed number from the analyzed data; no fabricated statistics.",
        "Apply basic web security practices: output escaping, CSRF protection, upload limits, safe export, no stack traces shown to users.",
        "Provide a fictional sample dataset and automated tests so the results can be reproduced."])
s += [P("3. Scope and technology", H1),
      P("<b>In scope:</b> login-event CSV analysis, four detection rules, dashboard, alert details, filtering, CSV export, documentation. <b>Out of scope:</b> real-time log collection, other log formats, user accounts, databases, geolocation, threat-intelligence feeds and machine learning."),
      table([["Component", "Choice", "Reason"],
             ["Language / backend", "Python 3, Flask", "Beginner-friendly, readable, single dependency"],
             ["Frontend", "HTML, CSS, small JavaScript file", "No build tools; works without JavaScript"],
             ["Charts", "Server-rendered inline SVG", "Drawn from real data; works under a strict Content-Security-Policy"],
             ["Data format", "CSV in, CSV out", "Universal and easy to inspect"],
             ["Testing", "Python unittest, Playwright (optional)", "unittest ships with Python; Playwright drives a real browser"],
             ["Version control", "Git", "Standard practice"]],
            [4 * cm, 5.2 * cm, 7.3 * cm]),
      PageBreak()]

# ---------------------------------------------------------------- architecture
s += [P("4. System design", H1),
      P("The code is split so that the analysis logic can be tested without the web layer. The <font face='Courier'>engine</font> package contains the parser, detection rules and summary metrics and does not import Flask. The web layer calls the engine, keeps the result in memory, and renders it."),
      architecture(), Spacer(1, 6),
      table([["Module", "Responsibility"],
             ["engine/parser.py", "Validates the upload (empty, binary, size, UTF-8, columns) and parses rows; bad rows are skipped and reported with line numbers."],
             ["engine/detector.py", "Implements the four rules and produces alerts with stable IDs (LD-0001, ...). Output does not depend on input order."],
             ["engine/rules.py", "The text shown for each rule: how it works, severity logic, recommended action, limitations."],
             ["engine/summary.py", "Dashboard metrics and timeline buckets computed from real events."],
             ["filters.py / exporter.py", "Alert filtering and sorting; CSV export with formula-injection protection."],
             ["store.py", "In-memory store keyed by a random session token; entries expire after 2 hours."],
             ["app.py", "Flask routes, CSRF check, security headers, friendly error pages."]],
            [4.2 * cm, 12.3 * cm]),
      P("<b>Workflow.</b> Upload (or load the sample) &rarr; validate &rarr; parse into events &rarr; run rules &rarr; build summary and timeline &rarr; store in memory &rarr; show dashboard &rarr; open an alert, filter, or export.", BODY),
      P("5. Methodology: detection rules", H1),
      P("Each rule is a transparent threshold. Defaults are conservative starting points for small demonstration data, not values tuned for a real network. All thresholds can be changed in the interface. A time window includes its end points."),
      table([["Rule", "Default threshold", "Severity"],
             ["1. Repeated failed logins", "At least 5 failures on one account within 10 minutes. Overlapping windows are merged into one alert.", "Medium; High at 10 or more"],
             ["2. Success after failures", "A success preceded by at least 3 failures on the same account within the previous 10 minutes. A success resets the count.", "Medium; High at 6 or more"],
             ["3. Failures across multiple accounts", "One source address failing against at least 4 different accounts within 10 minutes (password-spraying pattern).", "Medium; High at 8 or more accounts"],
             ["4. Login outside expected hours", "Runs only if an expected start and end hour are set. Start included, end excluded; midnight-crossing schedules supported. Successful logins only.", "Low"]],
            [4.3 * cm, 8.6 * cm, 3.6 * cm]),
      P("<b>Important:</b> a match is a lead to investigate. It is never described as proof of malicious intent, and each alert lists its own false-positive causes (for example forgotten passwords, shared office addresses, shift workers)."),
      P("<b>Overlapping alerts.</b> One event can support more than one alert, for example failures that form a burst and also precede a successful login. The dashboard metric &ldquo;flagged events&rdquo; counts each event once, so it is never inflated by overlap.")]
s.append(PageBreak())

# ---------------------------------------------------------------- implementation / security
s += [P("6. Implementation highlights", H1)]
s += B(["<b>Validation.</b> Whole-file problems (empty, binary, not UTF-8, missing or duplicated columns, over 2 MB, over 50,000 rows) reject the upload with a clear message. Row-level problems (bad timestamp, invalid IP, unknown status, missing or overlong username) skip only that row and are listed on the dashboard.",
        "<b>Explainability.</b> Every alert carries its ID, rule, severity, accounts, sources, first and last time, supporting event line numbers, an explanation containing the actual numbers, a recommended action and the rule's limitations.",
        "<b>Timestamps.</b> ISO 8601 with a time of day. Timestamps with a timezone are converted to UTC; others are used as written. All times are displayed as UTC.",
        "<b>Interface.</b> Dark theme with one accent colour, severity shown as text as well as colour, a chart with a data-table alternative, keyboard-focus styles, and a layout that turns tables into stacked cards on phones.",
        "<b>Privacy.</b> Only four columns are read. Extra columns (including a password column, should someone include one) are ignored and never stored or shown. Uploaded data lives only in server memory."])
s += [P("7. Security measures", H1),
      table([["Risk", "Measure", "Verified by"],
             ["Cross-site scripting", "All values are HTML-escaped by the template engine; Content-Security-Policy forbids inline scripts and styles.", "Tests inject script tags in usernames, file names and filter values"],
             ["Cross-site request forgery", "Every POST needs a per-session token compared in constant time.", "Tests send missing, forged and non-ASCII tokens"],
             ["Spreadsheet formula injection", "Export cells starting with = + - @ tab or CR get a leading apostrophe.", "Test exports usernames beginning with each character"],
             ["Oversized or malicious uploads", "2 MB / 50,000-row limits; the server never reads past the limit; binary files rejected.", "Tests for size, rows, binary content"],
             ["Information leakage", "Stack traces go to the server log only; users see a generic message. Debug mode is off.", "Test forces an internal error and checks the page"],
             ["Data retention", "Memory only, 2-hour expiry, 'Clear data' button, nothing written to disk.", "Store tests (expiry, eviction, delete)"],
             ["Other", "nosniff, X-Frame-Options DENY, no-referrer, no-store caching, HttpOnly SameSite cookie; server binds to 127.0.0.1.", "Header tests, live header check"]],
            [3.6 * cm, 7.4 * cm, 5.5 * cm]),
      PageBreak()]

# ---------------------------------------------------------------- testing
s += [P("8. Testing and results", H1),
      P("All results below are from runs on the delivered code. The test environment was Python 3.13 with Flask 3.1."),
      P("8.1 Automated tests", H2),
      table([["Test file", "Tests", "What it covers"],
             ["test_detection.py", "43", "Each rule: below/at threshold, window boundaries, severity, per-account separation, reset after success, midnight-crossing schedule, input-order independence, configuration limits"],
             ["test_parser.py", "26", "Valid files, column order, BOM, timezones, IPv6, bad rows, empty/binary/oversized/non-UTF-8 files"],
             ["test_sample_data.py", "6", "The sample dataset produces exactly the planted findings and nothing else"],
             ["test_support_modules.py", "20", "Store expiry and eviction, export safety, filter parsing, summary maths, chart geometry"],
             ["test_app.py", "55", "Startup, branding, upload workflow, CSRF, XSS, security headers, filters, export, error pages"],
             ["<b>Total</b>", "<b>150</b>", "<b>All passed (OK, 0 failures)</b>, also with deprecation warnings treated as errors"]],
            [4 * cm, 1.6 * cm, 10.9 * cm]),
      P("<b>Do the tests detect real faults?</b> Four deliberate bugs were introduced into a scratch copy of the detector: a threshold off-by-one, an exclusive window boundary, a missing reset after success, and ignoring the &ldquo;schedule configured&rdquo; guard. The suite failed in every case (7, 1, 2 and 14 failing tests respectively), so these tests do catch the mistakes they target."),
      P("8.2 Browser-driven checks", H2),
      P("A script (<font face='Courier'>scripts/capture_screenshots.py</font>) starts the real application and drives it in headless Chromium: loading the sample, filtering, downloading the filtered export, opening an alert, uploading an invalid file, enabling the schedule rule, and viewing a phone-sized 390-pixel layout. <b>25 of 25 checks passed</b>, including no horizontal scrolling on phone width and no console errors or Content-Security-Policy violations. Only Chromium was used; other browsers and physical devices were not tested."),
      P("8.3 Results on the sample dataset", H2),
      P(f"The fictional sample contains {summary.total_events} events ({summary.failed_logins} failures, {summary.successful_logins} successes), {summary.unique_accounts} account names and {summary.unique_sources} source addresses. Attack-like scenarios were planted on purpose, alongside ordinary logins and single typos that must not alert. With default settings LogDecipher reported <b>{summary.alert_groups} alert groups</b> covering <b>{summary.flagged_events} flagged events</b> ({summary.flagged_percent}%). With an expected schedule of 08:00 to 18:00, {len(alerts_sched) - len(alerts)} additional low-severity alerts appear.")]
rows = [["ID", "Severity", "Rule", "Account", "Source", "Events"]]
for a in alerts:
    rows.append([a.alert_id, a.severity.capitalize(), a.rule_name, a.account_label, a.source_label, a.event_count])
s += [table(rows, [1.8 * cm, 1.8 * cm, 5.2 * cm, 2.8 * cm, 3.2 * cm, 1.7 * cm]), Spacer(1, 6),
      P("The medium-severity &ldquo;success after failures&rdquo; alert for one account (three mistyped passwords followed by a success from the same address) is deliberately ordinary behaviour. It shows why the rule has false positives and why the alert text says so. The planted slow-spread scenario, where six different addresses each try one account once, is found by the per-account rule but correctly not by the multi-account rule.", BODY),
      P("8.4 Not verified", H2)]
s += B(["No testing with real-world logs; accuracy and false-positive rates on real networks are unknown.",
        "No performance testing beyond the 50,000-row limit; no load or concurrency testing.",
        "No testing in Firefox, Safari, or on physical phones.",
        "No independent security review or penetration test."])
s.append(PageBreak())

# ---------------------------------------------------------------- screenshots
s += [P("9. Screenshots of the running application", H1),
      P("Captured from the real application by the browser script above, using the fictional sample dataset."),
      shot("01-empty-state.png", "Figure 1: Start page with upload form, sample dataset button and expected file format", max_h=9 * cm),
      shot("02-dashboard.png", "Figure 2: Dashboard with metrics, severity distribution and rules in use", max_h=9.5 * cm),
      shot("03-dashboard-full-page.png", "Figure 3: Full dashboard: event timeline and alert list with filters", max_h=17 * cm),
      shot("05-alert-detail.png", "Figure 4: Alert LD-0005 detail page: explanation, recommended action, limitations, supporting events", max_h=17 * cm),
      shot("07-upload-error.png", "Figure 5: A file with missing columns is rejected with a clear message; the previous analysis is kept", max_h=9.5 * cm),
      shot("09-mobile-dashboard.png", "Figure 6: Phone-sized layout (390 px wide)", width=6.5 * cm, max_h=12 * cm),
      PageBreak()]

# ---------------------------------------------------------------- limitations etc
s += [P("10. Limitations", H1)]
s += B(["Thresholds are simple and fixed per run; attackers who stay under them, or spread attempts over longer than the window, are not detected.",
        "Normal behaviour (typos, shared addresses, shift work, travel) can trigger alerts. The tool cannot see what happened after a login.",
        "One expected schedule applies to every account, and timestamps are treated as UTC.",
        "Only login-event CSV files are supported. There is no real-time ingestion.",
        "Single-user local design: no authentication, so it should not be exposed to the internet as is.",
        "Results are not saved between server restarts (by design, for privacy)."])
s += [P("11. Future improvements", H1)]
s += B(["Support more log formats (SSH, web server, Windows event logs).",
        "Per-account schedules, allow-lists for known addresses, and rule tuning from baselines.",
        "Optional persistent storage, user login, and PDF report export.",
        "Geolocation and threat-intelligence context, only where authorized and privacy-safe.",
        "Optional statistical or machine-learning detection once the rule-based version is understood and measured."]
        )
s += [P("12. Development approach and disclosure", H1),
      P("The project was planned, supervised, reviewed and tested by the student author. An AI coding assistant (Claude, by Anthropic) was used to help write and test the code, documentation and this report; the generated work was reviewed by the author, and the numbers in this report come from running the delivered code. This disclosure is included so the report is transparent about how it was produced; it should be adjusted if the course policy requires a different statement."),
      P("13. Conclusion", H1),
      P("LogDecipher meets its main goals: it analyzes login-event files, detects four categories of suspicious login behaviour with transparent rules, explains each alert with actions and limitations, validates input safely, and exports findings securely. It is intentionally small and honest about its limits, which makes it a suitable foundation for learning how SIEM-style detection works."),
      P("Appendix A: How to run", H1),
      Preformatted("python -m venv .venv\nsource .venv/bin/activate   # Windows: .venv\\Scripts\\activate\npip install -r requirements.txt\npython run.py                # open http://127.0.0.1:5000\npython -m unittest discover -s tests", CODE),
      PageBreak(), P("Appendix B: Short viva questions", H1)]
qa = [("What does LogDecipher do?", "It reads a CSV of login events, applies four threshold rules, and shows alerts with an explanation, a recommended action and the limitations of each rule."),
      ("What is a SIEM and how is this related?", "A SIEM collects logs, correlates events and raises alerts. LogDecipher is a small educational version of the detect-and-explain part, not a real SIEM."),
      ("Why are the rules threshold-based and not machine learning?", "Thresholds are easy to explain and test, which suits a first version. Every alert can state exactly why it matched."),
      ("What is password spraying?", "Trying a few common passwords against many accounts, usually from one source, to avoid lockouts. Rule 3 looks for one source failing against many accounts."),
      ("Does an alert mean an attack happened?", "No. It means a pattern deserves investigation. Typos, shared addresses and shift work can cause alerts, and each alert lists such false positives."),
      ("How do you stop a malicious username like =HYPERLINK(...) from harming a spreadsheet user?", "Export cells starting with =, +, -, @, tab or carriage return get a leading apostrophe so spreadsheets treat them as text."),
      ("How is cross-site scripting prevented?", "Templates escape every value, and the Content-Security-Policy blocks inline scripts. Tests inject script tags and confirm they appear only as escaped text."),
      ("Why is no data stored on disk?", "To limit retention of possibly sensitive logs. Results stay in memory, expire after two hours and can be cleared by the user."),
      ("How do you know the tests are meaningful?", "Deliberate bugs were introduced in a copy of the detector and the tests failed each time."),
      ("What would you improve first?", "Per-account schedules and allow-lists to reduce false positives, then more log formats.")]
for q, a in qa:
    s.append(KeepTogether([P(f"<b>Q. {q}</b>", BODY), P(a, ParagraphStyle('ans', parent=BODY, leftIndent=12))]))

doc = SimpleDocTemplate(str(OUT), pagesize=A4, leftMargin=2 * cm, rightMargin=2 * cm, topMargin=2 * cm, bottomMargin=2 * cm,
                        title="LogDecipher — Explainable Cybersecurity Log Analysis Platform: Project Report",
                        author="Tanishq Saini", subject="Project report")
doc.build(s, onLaterPages=footer)
print("wrote", OUT, OUT.stat().st_size, "bytes")
