#!/usr/bin/env python3
"""Drive the real LogDecipher interface in a headless browser.

This script starts the application on a free local port, walks through the main workflows the
way a person would (upload, sample data, filters, alert details, export, error handling),
checks a few interface properties, and saves screenshots to docs/screenshots/.

It needs the optional development dependency Playwright and a Chromium browser:
    pip install -r requirements-dev.txt
    python -m playwright install chromium
    python scripts/capture_screenshots.py
"""
from __future__ import annotations

import csv
import io
import sys
import tempfile
import threading
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from playwright.sync_api import sync_playwright  # noqa: E402
from werkzeug.serving import make_server  # noqa: E402

from logdecipher import create_app  # noqa: E402

SHOTS = ROOT / "docs" / "screenshots"
DESKTOP = {"width": 1280, "height": 800}
MOBILE = {"width": 390, "height": 844}

results = []


def check(name: str, ok: bool, detail: str = "") -> None:
    results.append((name, ok, detail))
    print(f"[{'PASS' if ok else 'FAIL'}] {name}" + (f" - {detail}" if detail else ""))


def no_horizontal_overflow(page) -> tuple:
    scroll, inner = page.evaluate("[document.documentElement.scrollWidth, window.innerWidth]")
    return scroll <= inner, f"scrollWidth={scroll}, innerWidth={inner}"


def main() -> int:
    SHOTS.mkdir(parents=True, exist_ok=True)
    app = create_app()
    server = make_server("127.0.0.1", 0, app, threaded=True)
    base = f"http://127.0.0.1:{server.server_port}"
    threading.Thread(target=server.serve_forever, daemon=True).start()

    console_problems = []

    with sync_playwright() as pw:
        browser = pw.chromium.launch()
        context = browser.new_context(viewport=DESKTOP, accept_downloads=True)
        page = context.new_page()
        page.on("console", lambda m: console_problems.append(m.text) if m.type in ("error", "warning") else None)
        page.on("pageerror", lambda e: console_problems.append(f"pageerror: {e}"))

        # 1. Empty state
        page.goto(base + "/")
        check("Empty state shows product name in title", "LogDecipher" in page.title(), page.title())
        check("Empty state offers upload and sample", page.get_by_role("button", name="Use fictional sample dataset").is_visible())
        page.screenshot(path=str(SHOTS / "01-empty-state.png"))

        # 2. Load the sample dataset through the real button
        page.get_by_role("button", name="Use fictional sample dataset").click()
        page.wait_for_load_state()
        check("Sample dataset loads and shows a success message", page.locator(".flash-success").is_visible())
        check("Dashboard lists 6 alerts", page.locator("tr.alert-row").count() == 6, f"rows={page.locator('tr.alert-row').count()}")
        stats = page.locator(".stats").inner_text()
        check("Events analyzed metric shows 109", "109" in stats)
        check("Flagged events metric shows 45", "45" in stats)
        page.screenshot(path=str(SHOTS / "02-dashboard.png"))
        page.screenshot(path=str(SHOTS / "03-dashboard-full-page.png"), full_page=True)

        # 3. Filter by severity using the form
        page.select_option("#f-severity", "high")
        page.get_by_role("button", name="Apply filters").click()
        page.wait_for_load_state()
        check("Severity filter keeps only high alerts", page.locator("tr.alert-row").count() == 3 and "severity=high" in page.url)
        check("Filter results contain no medium badge", page.locator(".badge-medium").count() == 0)
        page.locator("#alerts").scroll_into_view_if_needed()
        page.screenshot(path=str(SHOTS / "04-filtered-alerts.png"))

        # 4. Export respects the filter and downloads a real file
        with page.expect_download() as info:
            page.get_by_role("link", name="Export CSV (filtered)").click()
        saved = Path(tempfile.mkdtemp()) / "export.csv"
        info.value.save_as(str(saved))
        rows = list(csv.DictReader(io.StringIO(saved.read_text(encoding="utf-8-sig"))))
        check("Filtered export downloads 3 high-severity rows", len(rows) == 3 and {r["severity"] for r in rows} == {"high"}, f"rows={len(rows)}")
        check("Download file name is logdecipher_findings.csv", info.value.suggested_filename == "logdecipher_findings.csv")

        # 5. Reset filter and open an alert
        page.get_by_role("link", name="Reset").click()
        page.wait_for_load_state()
        check("Reset shows all 6 alerts again", page.locator("tr.alert-row").count() == 6)
        page.locator("tr.alert-row a").first.click()
        page.wait_for_load_state()
        body = page.locator("main").inner_text()
        for phrase in ("Why this matched", "Recommended defensive action", "Limitations and possible false positives", "Supporting events"):
            check(f"Alert page shows '{phrase}'", phrase in body)
        page.screenshot(path=str(SHOTS / "05-alert-detail.png"), full_page=True)

        # 6. Rules page
        page.get_by_role("link", name="Detection rules").click()
        page.wait_for_load_state()
        check("Rules page lists four rules", page.locator(".rule-card").count() == 4)
        page.screenshot(path=str(SHOTS / "06-detection-rules.png"), full_page=True)

        # 7. Invalid upload through the real file chooser
        page.get_by_role("link", name="Dashboard").click()
        page.locator("details.disclosure > summary").click()
        bad = Path(tempfile.mkdtemp()) / "broken.csv"
        bad.write_text("timestamp,username\n2026-03-02 10:00:00,alice\n", encoding="utf-8")
        page.set_input_files("#logfile", str(bad))
        page.get_by_role("button", name="Analyze file").click()
        page.wait_for_load_state()
        check("Invalid file shows a clear error", page.locator(".flash-error").is_visible() and "source_ip" in page.locator(".flash-error").inner_text())
        check("Previous analysis is untouched after a failed upload", page.locator("tr.alert-row").count() == 6)
        page.screenshot(path=str(SHOTS / "07-upload-error.png"))

        # 8. Settings: enabling the unusual-time rule through the UI
        page.locator("details.disclosure > summary").click()
        page.locator("details.settings > summary").click()
        page.fill("#schedule_start_hour", "8")
        page.fill("#schedule_end_hour", "18")
        page.get_by_role("button", name="Use fictional sample dataset").click()
        page.wait_for_load_state()
        check("Configured schedule adds the 2 unusual-time alerts", page.locator("tr.alert-row").count() == 8)

        # 9. Mobile layout
        mobile = browser.new_context(viewport=MOBILE, device_scale_factor=2, has_touch=True, is_mobile=True)
        mpage = mobile.new_page()
        mpage.on("console", lambda m: console_problems.append(m.text) if m.type in ("error", "warning") else None)
        mpage.goto(base + "/")
        ok, detail = no_horizontal_overflow(mpage)
        check("Mobile empty state has no horizontal scrolling", ok, detail)
        mpage.screenshot(path=str(SHOTS / "08-mobile-empty-state.png"))
        mpage.get_by_role("button", name="Use fictional sample dataset").click()
        mpage.wait_for_load_state()
        ok, detail = no_horizontal_overflow(mpage)
        check("Mobile dashboard has no horizontal scrolling", ok, detail)
        mpage.screenshot(path=str(SHOTS / "09-mobile-dashboard.png"))
        mpage.locator("#alerts").scroll_into_view_if_needed()
        mpage.evaluate("document.getElementById('alerts').scrollIntoView()")
        thead_visible = mpage.locator(".alerts-table thead").evaluate("el => { const r = el.getBoundingClientRect(); return r.width > 2 && r.height > 2; }")
        check("Mobile alert table is shown as stacked cards", not thead_visible)
        mpage.screenshot(path=str(SHOTS / "10-mobile-alerts.png"))
        mpage.locator("tr.alert-row a").first.click()
        mpage.wait_for_load_state()
        ok, detail = no_horizontal_overflow(mpage)
        check("Mobile alert page has no horizontal scrolling", ok, detail)
        mpage.screenshot(path=str(SHOTS / "11-mobile-alert-detail.png"), full_page=True)
        mpage.goto(base + "/rules")
        ok, detail = no_horizontal_overflow(mpage)
        check("Mobile rules page has no horizontal scrolling", ok, detail)

        # 10. Console health (includes any Content-Security-Policy violations)
        check("No browser console errors or warnings", not console_problems, "; ".join(console_problems[:3]))

        browser.close()

    server.shutdown()
    failed = [name for name, ok, _ in results if not ok]
    print(f"\n{len(results) - len(failed)} of {len(results)} browser checks passed.")
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main())
