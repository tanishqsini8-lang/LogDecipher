"""Start LogDecipher locally:  python run.py   then open http://127.0.0.1:5000"""
import os

from logdecipher import create_app

app = create_app()

if __name__ == "__main__":
    host = os.environ.get("LOGDECIPHER_HOST", "127.0.0.1")  # local only by default
    port = int(os.environ.get("LOGDECIPHER_PORT", "5000"))
    app.run(host=host, port=port, debug=False)
