"""CSV export of findings, hardened against spreadsheet formula injection.

Usernames and other values come from the uploaded file, so they are untrusted. A cell that
starts with = + - @ (or a tab, carriage return or newline) can be run as a formula by
spreadsheet programs. Such cells are prefixed with an apostrophe so they open as plain text.
"""
from __future__ import annotations

import csv
import io
from typing import Iterable

from .engine.formatting import format_timestamp
from .engine.models import Alert

FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r", "\n")
MAX_LINES_IN_CELL = 200

COLUMNS = (
    "alert_id",
    "severity",
    "rule",
    "accounts",
    "source_ips",
    "first_seen_utc",
    "last_seen_utc",
    "event_count",
    "supporting_event_lines",
    "explanation",
    "recommended_action",
    "limitations",
)


def csv_safe(value: object) -> str:
    """Return the value as text that a spreadsheet will not interpret as a formula."""
    text = "" if value is None else str(value)
    if text.startswith(FORMULA_PREFIXES):
        return "'" + text
    return text


def _lines_cell(lines: Iterable[int]) -> str:
    lines = list(lines)
    shown = "; ".join(str(n) for n in lines[:MAX_LINES_IN_CELL])
    if len(lines) > MAX_LINES_IN_CELL:
        shown += f"; ... (+{len(lines) - MAX_LINES_IN_CELL} more)"
    return shown


def alerts_to_csv(alerts: Iterable[Alert]) -> str:
    """Serialise alerts. A UTF-8 byte-order mark is added so Excel reads non-ASCII names correctly."""
    buffer = io.StringIO()
    writer = csv.writer(buffer, quoting=csv.QUOTE_ALL, lineterminator="\r\n")
    writer.writerow(COLUMNS)
    for alert in alerts:
        writer.writerow(
            [
                csv_safe(alert.alert_id),
                csv_safe(alert.severity),
                csv_safe(alert.rule_name),
                csv_safe("; ".join(alert.usernames)),
                csv_safe("; ".join(alert.source_ips)),
                csv_safe(format_timestamp(alert.start)),
                csv_safe(format_timestamp(alert.end)),
                alert.event_count,
                csv_safe(_lines_cell(alert.event_lines)),
                csv_safe(alert.explanation),
                csv_safe(alert.recommendation),
                csv_safe(alert.limitations),
            ]
        )
    return "﻿" + buffer.getvalue()
