"""Dashboard metrics computed from the real events and alerts (nothing is estimated)."""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import Dict, Iterable, List, Optional, Sequence, Set, Tuple

from .models import SEVERITY_ORDER, Alert, LoginEvent

BUCKET_SIZES_MINUTES = (1, 2, 5, 10, 15, 30, 60, 120, 180, 360, 720, 1440, 2880, 10080, 43200)
_EPOCH = datetime(1970, 1, 1)


@dataclass(frozen=True)
class Summary:
    total_events: int
    failed_logins: int
    successful_logins: int
    unique_accounts: int
    unique_sources: int
    alert_groups: int
    flagged_events: int  # each event counted once, even if several alerts include it
    flagged_percent: float
    rules_triggered: int
    severity_counts: Dict[str, int]
    first_event: Optional[datetime]
    last_event: Optional[datetime]


@dataclass(frozen=True)
class Bucket:
    start: datetime
    total: int
    flagged: int


@dataclass(frozen=True)
class Timeline:
    bucket_minutes: int
    buckets: Tuple[Bucket, ...]
    max_total: int


def flagged_lines(alerts: Iterable[Alert]) -> Set[int]:
    lines: Set[int] = set()
    for alert in alerts:
        lines.update(alert.event_lines)
    return lines


def build_summary(events: Sequence[LoginEvent], alerts: Sequence[Alert]) -> Summary:
    flagged = flagged_lines(alerts)
    severity_counts = {level: 0 for level in SEVERITY_ORDER}
    for alert in alerts:
        severity_counts[alert.severity] += 1
    total = len(events)
    failed = sum(1 for e in events if not e.success)
    timestamps = [e.timestamp for e in events]
    return Summary(
        total_events=total,
        failed_logins=failed,
        successful_logins=total - failed,
        unique_accounts=len({e.username for e in events}),
        unique_sources=len({e.source_ip for e in events}),
        alert_groups=len(alerts),
        flagged_events=len(flagged),
        flagged_percent=round(100 * len(flagged) / total, 1) if total else 0.0,
        rules_triggered=len({a.rule_id for a in alerts}),
        severity_counts=severity_counts,
        first_event=min(timestamps) if timestamps else None,
        last_event=max(timestamps) if timestamps else None,
    )


def _floor(moment: datetime, minutes: int) -> datetime:
    size = minutes * 60
    seconds = int((moment - _EPOCH).total_seconds())
    return _EPOCH + timedelta(seconds=seconds - seconds % size)


def build_timeline(
    events: Sequence[LoginEvent], flagged: Set[int], max_buckets: int = 48
) -> Timeline:
    """Count events (and flagged events) per time bucket. The bucket size adapts to the data span."""
    first = min(e.timestamp for e in events)
    last = max(e.timestamp for e in events)
    span_minutes = (last - first).total_seconds() / 60
    size = next(
        (s for s in BUCKET_SIZES_MINUTES if span_minutes / s + 2 <= max_buckets),
        BUCKET_SIZES_MINUTES[-1],
    )

    totals: Counter = Counter()
    flags: Counter = Counter()
    for event in events:
        bucket = _floor(event.timestamp, size)
        totals[bucket] += 1
        if event.line in flagged:
            flags[bucket] += 1

    buckets: List[Bucket] = []
    cursor = _floor(first, size)
    end = _floor(last, size)
    step = timedelta(minutes=size)
    while cursor <= end:
        buckets.append(Bucket(start=cursor, total=totals[cursor], flagged=flags[cursor]))
        cursor += step
    return Timeline(
        bucket_minutes=size,
        buckets=tuple(buckets),
        max_total=max((b.total for b in buckets), default=0),
    )


def describe_bucket_size(minutes: int) -> str:
    if minutes < 60:
        return f"{minutes} minute{'s' if minutes != 1 else ''}"
    if minutes < 1440:
        hours = minutes // 60
        return f"{hours} hour{'s' if hours != 1 else ''}"
    days = minutes // 1440
    return f"{days} day{'s' if days != 1 else ''}"
