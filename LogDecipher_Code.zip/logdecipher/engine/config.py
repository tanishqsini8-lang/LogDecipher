"""Detection settings shared by the engine and the web layer."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import timedelta
from typing import Optional


class ConfigError(ValueError):
    """Raised when detection settings are out of range. The message is safe to show to users."""


def _check_int(name: str, value, low: int, high: int) -> None:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ConfigError(f"{name} must be a whole number.")
    if not low <= value <= high:
        raise ConfigError(f"{name} must be between {low} and {high}.")


@dataclass(frozen=True)
class DetectionConfig:
    """All thresholds used by the detection rules.

    Defaults are deliberately conservative starting points for a small demo dataset,
    not values tuned for any real environment.
    """

    window_minutes: int = 10
    failure_threshold: int = 5
    success_after_failures_threshold: int = 3
    spray_account_threshold: int = 4
    # Optional unusual-time rule: only active when BOTH hours are set.
    schedule_start_hour: Optional[int] = None
    schedule_end_hour: Optional[int] = None

    @property
    def window(self) -> timedelta:
        return timedelta(minutes=self.window_minutes)

    @property
    def schedule_enabled(self) -> bool:
        return self.schedule_start_hour is not None and self.schedule_end_hour is not None

    def validate(self) -> None:
        _check_int("Time window (minutes)", self.window_minutes, 1, 1440)
        _check_int("Repeated-failure threshold", self.failure_threshold, 2, 1000)
        _check_int(
            "Success-after-failures threshold",
            self.success_after_failures_threshold,
            2,
            1000,
        )
        _check_int("Multi-account threshold", self.spray_account_threshold, 2, 1000)

        start, end = self.schedule_start_hour, self.schedule_end_hour
        if (start is None) != (end is None):
            raise ConfigError(
                "Set both the expected start hour and end hour, or leave both empty."
            )
        if start is not None:
            _check_int("Expected start hour", start, 0, 23)
            _check_int("Expected end hour", end, 0, 23)
            if start == end:
                raise ConfigError("The expected start hour and end hour must be different.")
