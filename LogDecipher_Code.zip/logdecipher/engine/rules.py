"""Human-readable descriptions of each detection rule.

These texts are shown on the "Detection rules" page, on every alert, and in exported
findings, so they are written to match exactly what ``detector.py`` implements.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List

REPEATED_FAILURES = "repeated_failures"
SUCCESS_AFTER_FAILURES = "success_after_failures"
MULTI_ACCOUNT_FAILURES = "multi_account_failures"
UNUSUAL_TIME = "unusual_time"

RULE_ORDER = {
    REPEATED_FAILURES: 0,
    SUCCESS_AFTER_FAILURES: 1,
    MULTI_ACCOUNT_FAILURES: 2,
    UNUSUAL_TIME: 3,
}


@dataclass(frozen=True)
class RuleInfo:
    rule_id: str
    name: str
    summary: str
    how_it_works: str
    severity_logic: str
    recommendation: str
    limitations: str


RULES: Dict[str, RuleInfo] = {
    REPEATED_FAILURES: RuleInfo(
        rule_id=REPEATED_FAILURES,
        name="Repeated failed logins",
        summary="Many failed logins against one account in a short time.",
        how_it_works=(
            "Failed logins are grouped by account and a time window is slid across them. "
            "When an account has at least the threshold number of failures inside one window, "
            "those failures are reported as a single alert. Overlapping or adjacent windows "
            "are merged, so one burst of failures produces one alert."
        ),
        severity_logic=(
            "Medium when the failures reach the threshold; High when they reach twice the threshold."
        ),
        recommendation=(
            "Check whether the account owner was locked out or mistyping a password. If not, "
            "review the source address(es), consider temporary rate-limiting or account lockout, "
            "and confirm the account uses a strong, unique password and multi-factor authentication."
        ),
        limitations=(
            "A forgotten password, an outdated saved password on a phone or script, or a "
            "misconfigured service can look identical to guessing. Attempts that stay below the "
            "threshold, or are spread over longer than the window, are not detected. Failures from "
            "several sources are combined per account, so the source may show several addresses."
        ),
    ),
    SUCCESS_AFTER_FAILURES: RuleInfo(
        rule_id=SUCCESS_AFTER_FAILURES,
        name="Success after repeated failures",
        summary="A successful login right after a run of failed logins for the same account.",
        how_it_works=(
            "For each account, the failures since its last successful login are remembered. When a "
            "success arrives and at least the threshold number of those failures happened inside the "
            "time window before it, an alert is raised. The failure count is reset after every success."
        ),
        severity_logic=(
            "Medium when the failures reach the threshold; High when they reach twice the threshold."
        ),
        recommendation=(
            "Ask the account owner to confirm the login. If they cannot, treat the account as "
            "potentially compromised: reset the credential, end active sessions, and review what the "
            "account did after the login."
        ),
        limitations=(
            "People often mistype a password a few times before succeeding, so this rule can flag "
            "normal behaviour, especially with a low threshold. A success from the same address as the "
            "failures is not proof of compromise, and a success from a different address is not proof "
            "of safety. LogDecipher cannot see what happened after the login."
        ),
    ),
    MULTI_ACCOUNT_FAILURES: RuleInfo(
        rule_id=MULTI_ACCOUNT_FAILURES,
        name="Failures across multiple accounts",
        summary="One source address failing to log in to several different accounts.",
        how_it_works=(
            "Failed logins are grouped by source address. When one source fails against at least the "
            "threshold number of different accounts inside the time window, those failures are "
            "reported as a single alert. This pattern is often called password spraying."
        ),
        severity_logic=(
            "Medium when the number of accounts reaches the threshold; High when it reaches twice the threshold."
        ),
        recommendation=(
            "Look up the source address in firewall or authentication logs. If it is not a known "
            "system, consider blocking or rate-limiting it, and check whether any targeted account "
            "later logged in successfully."
        ),
        limitations=(
            "Many users behind one shared address (office NAT, VPN gateway, proxy, campus network) can "
            "look like password spraying, for example after a service outage or a password-policy "
            "change. Slow sprays that stay under the threshold, or that rotate source addresses, are "
            "not detected. The rule does not check whether the account names actually exist."
        ),
    ),
    UNUSUAL_TIME: RuleInfo(
        rule_id=UNUSUAL_TIME,
        name="Login outside expected hours",
        summary="A successful login outside an expected schedule that you configured.",
        how_it_works=(
            "This rule is off unless an expected schedule (start hour and end hour) is configured. "
            "Successful logins whose hour of day falls outside the schedule are grouped by account and "
            "calendar day. The start hour is included and the end hour is excluded; schedules that "
            "cross midnight (for example 22 to 6) are supported."
        ),
        severity_logic="Always Low, because a login at an unusual time is a weak signal on its own.",
        recommendation=(
            "Confirm with the account owner whether the login was expected (shift work, travel, "
            "on-call duty). If it was not, review the source address and the account's other activity."
        ),
        limitations=(
            "One schedule applies to every account, so shift workers, staff in other time zones and "
            "on-call engineers can trigger it. Timestamps are treated as UTC (timestamps with a "
            "timezone are converted to UTC; timestamps without one are used as written), so the "
            "schedule must use the same time basis as the log file. Only successful logins are checked."
        ),
    ),
}


def threshold_lines(rule_id: str, config) -> List[str]:
    """Current settings of one rule, as short lines for display."""
    if rule_id == REPEATED_FAILURES:
        return [
            f"At least {config.failure_threshold} failed logins for one account "
            f"within {config.window_minutes} minutes"
        ]
    if rule_id == SUCCESS_AFTER_FAILURES:
        return [
            f"At least {config.success_after_failures_threshold} failed logins for one account "
            f"within the {config.window_minutes} minutes before a success"
        ]
    if rule_id == MULTI_ACCOUNT_FAILURES:
        return [
            f"Failures from one source against at least {config.spray_account_threshold} "
            f"different accounts within {config.window_minutes} minutes"
        ]
    if rule_id == UNUSUAL_TIME:
        if config.schedule_enabled:
            return [
                f"Expected hours {config.schedule_start_hour:02d}:00 to "
                f"{config.schedule_end_hour:02d}:00 (UTC basis)"
            ]
        return ["Off: no expected schedule configured"]
    return []
