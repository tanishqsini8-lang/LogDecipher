"""Validation and parsing of uploaded login-event CSV files.

File-level problems (empty file, missing columns, too large, not text) reject the whole upload
with a clear message. Row-level problems (bad timestamp, bad address, unknown status) skip only
that row and are reported, so one bad line does not hide the rest of the data.

The parser never stores or asks for passwords: only four columns are read, and any extra
columns in the file are ignored.
"""
from __future__ import annotations

import csv
import io
import ipaddress
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import List, Optional, Union

from .models import LoginEvent

REQUIRED_COLUMNS = ("timestamp", "username", "source_ip", "status")
SUCCESS_VALUES = frozenset({"success", "successful", "succeeded", "ok", "accepted"})
FAILURE_VALUES = frozenset({"failure", "failed", "fail", "denied", "rejected"})

MAX_USERNAME_LENGTH = 128
DEFAULT_MAX_BYTES = 2 * 1024 * 1024
DEFAULT_MAX_ROWS = 50_000
DEFAULT_MAX_ISSUES = 100


class CsvValidationError(ValueError):
    """The whole file was rejected. The message is safe to show to users."""


@dataclass(frozen=True)
class RowIssue:
    line: int
    message: str


@dataclass
class ParseResult:
    events: List[LoginEvent]
    issues: List[RowIssue]  # capped; see skipped_rows for the full count
    skipped_rows: int
    total_rows: int

    @property
    def issues_truncated(self) -> bool:
        return self.skipped_rows > len(self.issues)


def _format_size(num_bytes: int) -> str:
    if num_bytes >= 1024 * 1024:
        value = num_bytes / (1024 * 1024)
        return f"{value:g} MB"
    return f"{max(num_bytes // 1024, 1)} KB" if num_bytes >= 1024 else f"{num_bytes} bytes"


def parse_timestamp(value: str) -> Optional[datetime]:
    """Parse an ISO 8601 timestamp that includes a time of day.

    Timestamps with a timezone are converted to UTC; timestamps without one are used as written.
    Returns a naive datetime, or None when the value is not usable.
    """
    text = value.strip()
    if not text or len(text) > 40:
        return None
    if "T" not in text and " " not in text:
        return None  # a bare date is not a login time
    if text[-1] in "zZ":
        text = text[:-1] + "+00:00"
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        return None
    if parsed.tzinfo is not None:
        parsed = parsed.astimezone(timezone.utc).replace(tzinfo=None)
    if not 1970 <= parsed.year <= 2100:
        return None
    return parsed


def _parse_status(value: str) -> Optional[bool]:
    normalised = value.strip().lower()
    if normalised in SUCCESS_VALUES:
        return True
    if normalised in FAILURE_VALUES:
        return False
    return None


def _check_header(header: List[str]) -> None:
    for name in REQUIRED_COLUMNS:
        if header.count(name) > 1:
            raise CsvValidationError(f"The header contains the column '{name}' more than once.")
    missing = [name for name in REQUIRED_COLUMNS if name not in header]
    if missing:
        raise CsvValidationError(
            f"Missing required column(s): {', '.join(missing)}. "
            f"The header row must include: {', '.join(REQUIRED_COLUMNS)}."
        )


def _parse_row(row: List[str], index: dict, line: int, header_length: int) -> Union[LoginEvent, str]:
    """Return a LoginEvent, or a short reason the row was skipped."""
    if len(row) != header_length:
        return f"expected {header_length} fields but found {len(row)}"

    timestamp = parse_timestamp(row[index["timestamp"]])
    if timestamp is None:
        return "invalid or missing timestamp (use ISO 8601, e.g. 2026-03-02 09:14:05)"

    username = row[index["username"]].strip()
    if not username:
        return "missing username"
    if len(username) > MAX_USERNAME_LENGTH:
        return f"username is longer than {MAX_USERNAME_LENGTH} characters"
    if any(ord(ch) < 32 or ord(ch) == 127 for ch in username):
        return "username contains control characters"

    try:
        source_ip = str(ipaddress.ip_address(row[index["source_ip"]].strip()))
    except ValueError:
        return "invalid source IP address"

    success = _parse_status(row[index["status"]])
    if success is None:
        return "unrecognised status (expected success or failure)"

    return LoginEvent(
        line=line,
        timestamp=timestamp,
        username=username.lower(),
        source_ip=source_ip,
        success=success,
    )


def parse_login_csv(
    raw: bytes,
    *,
    max_bytes: int = DEFAULT_MAX_BYTES,
    max_rows: int = DEFAULT_MAX_ROWS,
    max_issues: int = DEFAULT_MAX_ISSUES,
) -> ParseResult:
    """Validate and parse uploaded bytes. Raises CsvValidationError for file-level problems."""
    if len(raw) == 0:
        raise CsvValidationError(
            "The file is empty. Upload a CSV file with a header row and at least one login event."
        )
    if len(raw) > max_bytes:
        raise CsvValidationError(f"The file is larger than the {_format_size(max_bytes)} limit.")
    if b"\x00" in raw:
        raise CsvValidationError("The file looks like a binary file, not a CSV text file.")
    try:
        text = bytes(raw).decode("utf-8-sig")
    except UnicodeDecodeError:
        raise CsvValidationError(
            "The file is not valid UTF-8 text. Save it as CSV (UTF-8) and try again."
        ) from None
    if not text.strip():
        raise CsvValidationError("The file contains no data.")

    events: List[LoginEvent] = []
    issues: List[RowIssue] = []
    skipped = 0
    total_rows = 0

    reader = csv.reader(io.StringIO(text, newline=""))
    try:
        header: Optional[List[str]] = None
        for row in reader:
            if any(cell.strip() for cell in row):
                header = [cell.strip().lower() for cell in row]
                break
        if header is None:
            raise CsvValidationError("The file contains no data.")
        _check_header(header)
        index = {name: header.index(name) for name in REQUIRED_COLUMNS}

        for row in reader:
            if not any(cell.strip() for cell in row):
                continue  # blank line
            total_rows += 1
            if total_rows > max_rows:
                raise CsvValidationError(f"The file has more than {max_rows:,} rows, which is the limit.")
            outcome = _parse_row(row, index, reader.line_num, len(header))
            if isinstance(outcome, LoginEvent):
                events.append(outcome)
            else:
                skipped += 1
                if len(issues) < max_issues:
                    issues.append(RowIssue(line=reader.line_num, message=outcome))
    except csv.Error:
        raise CsvValidationError(
            "The file could not be read as CSV. Check for unbalanced quotation marks."
        ) from None

    if not events:
        message = "No valid login events were found."
        if total_rows == 0:
            message = "The file has a header row but no login events."
        elif issues:
            message += f" First problem: line {issues[0].line}: {issues[0].message}."
        raise CsvValidationError(message)

    return ParseResult(events=events, issues=issues, skipped_rows=skipped, total_rows=total_rows)
