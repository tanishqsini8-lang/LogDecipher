"""Data models shared by the parser, the detection engine and the web layer."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Tuple

SEVERITY_ORDER = ("high", "medium", "low")
SEVERITY_RANK = {"high": 3, "medium": 2, "low": 1}


@dataclass(frozen=True)
class LoginEvent:
    """One validated row of the uploaded file.

    ``line`` is the line number in the uploaded CSV, so every alert can point back to
    the exact rows that support it.
    """

    line: int
    timestamp: datetime  # naive datetime, interpreted as UTC
    username: str  # stored lower-case
    source_ip: str  # normalised textual IP address
    success: bool

    @property
    def result(self) -> str:
        return "success" if self.success else "failure"


@dataclass(frozen=True)
class Alert:
    """A finding produced by one detection rule, with everything needed to explain it."""

    alert_id: str
    rule_id: str
    rule_name: str
    severity: str
    usernames: Tuple[str, ...]
    source_ips: Tuple[str, ...]
    start: datetime
    end: datetime
    event_lines: Tuple[int, ...]
    explanation: str
    recommendation: str
    limitations: str

    @property
    def event_count(self) -> int:
        return len(self.event_lines)

    @property
    def account_label(self) -> str:
        if len(self.usernames) == 1:
            return self.usernames[0]
        return f"{len(self.usernames)} accounts"

    @property
    def source_label(self) -> str:
        if len(self.source_ips) == 1:
            return self.source_ips[0]
        return f"{len(self.source_ips)} sources"
