"""Detection engine: four transparent, threshold-based rules.

Every rule works on events sorted by time and produces ``Alert`` objects that carry the
supporting events, a plain-language explanation, a recommended action and the rule's
known limitations. Nothing here proves malicious intent; alerts are leads to investigate.
"""
from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import replace
from datetime import timedelta
from typing import Callable, Dict, Hashable, Iterable, List, Optional, Sequence

from .config import DetectionConfig
from .formatting import describe_sources, format_duration, format_timestamp
from .models import Alert, LoginEvent
from .rules import (
    MULTI_ACCOUNT_FAILURES,
    REPEATED_FAILURES,
    RULE_ORDER,
    RULES,
    SUCCESS_AFTER_FAILURES,
    UNUSUAL_TIME,
)


def analyze(events: Iterable[LoginEvent], config: Optional[DetectionConfig] = None) -> List[Alert]:
    """Run all enabled rules and return alerts with stable, sequential identifiers.

    The result does not depend on the order of the input events: they are sorted first, and
    alerts are ordered by start time, then rule, then subject, before identifiers are assigned.
    """
    config = config or DetectionConfig()
    config.validate()

    ordered = sorted(events, key=lambda e: (e.timestamp, e.line))
    drafts: List[Alert] = []
    drafts += _repeated_failures(ordered, config)
    drafts += _success_after_failures(ordered, config)
    drafts += _multi_account_failures(ordered, config)
    if config.schedule_enabled:
        drafts += _unusual_time(ordered, config)

    drafts.sort(key=lambda a: (a.start, RULE_ORDER[a.rule_id], a.usernames, a.source_ips, a.event_lines))
    return [replace(alert, alert_id=f"LD-{index:04d}") for index, alert in enumerate(drafts, start=1)]


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

def _qualifying_clusters(
    events: Sequence[LoginEvent],
    window: timedelta,
    key: Callable[[LoginEvent], Hashable],
    qualifies: Callable[[Counter, int], bool],
) -> List[List[LoginEvent]]:
    """Find groups of events that sit inside a qualifying sliding window.

    ``events`` must be sorted by time. A window is every run of events whose first and last
    timestamps are at most ``window`` apart (inclusive). ``qualifies(counter, size)`` receives a
    count of ``key`` values in the window and the number of events, and decides whether the window
    is suspicious. Every event belonging to at least one qualifying window is marked, and marked
    events that are close together are merged into one cluster so a long burst gives one alert.
    """
    count = len(events)
    marked = [False] * count
    counter: Counter = Counter()
    left = 0
    last_marked = -1

    for right in range(count):
        counter[key(events[right])] += 1
        while events[right].timestamp - events[left].timestamp > window:
            old_key = key(events[left])
            counter[old_key] -= 1
            if counter[old_key] == 0:
                del counter[old_key]
            left += 1
        if qualifies(counter, right - left + 1):
            # Left only moves forward, so everything in [left, last_marked] is already marked.
            for index in range(max(left, last_marked + 1), right + 1):
                marked[index] = True
            last_marked = right

    clusters: List[List[LoginEvent]] = []
    current: List[LoginEvent] = []
    for index, event in enumerate(events):
        if not marked[index]:
            continue
        if current and event.timestamp - current[-1].timestamp > window:
            clusters.append(current)
            current = []
        current.append(event)
    if current:
        clusters.append(current)
    return clusters


def _build_alert(
    rule_id: str,
    severity: str,
    usernames: Sequence[str],
    source_ips: Sequence[str],
    events: Sequence[LoginEvent],
    explanation: str,
) -> Alert:
    rule = RULES[rule_id]
    ordered = sorted(events, key=lambda e: (e.timestamp, e.line))
    return Alert(
        alert_id="",  # assigned once all alerts are known
        rule_id=rule_id,
        rule_name=rule.name,
        severity=severity,
        usernames=tuple(sorted(set(usernames))),
        source_ips=tuple(sorted(set(source_ips))),
        start=ordered[0].timestamp,
        end=ordered[-1].timestamp,
        event_lines=tuple(e.line for e in ordered),
        explanation=explanation,
        recommendation=rule.recommendation,
        limitations=rule.limitations,
    )


def _group_by(events: Iterable[LoginEvent], key: Callable[[LoginEvent], str]) -> Dict[str, List[LoginEvent]]:
    groups: Dict[str, List[LoginEvent]] = defaultdict(list)
    for event in events:
        groups[key(event)].append(event)
    return groups


# ---------------------------------------------------------------------------
# Rule 1: repeated failed logins against one account
# ---------------------------------------------------------------------------

def _repeated_failures(events: Sequence[LoginEvent], config: DetectionConfig) -> List[Alert]:
    threshold = config.failure_threshold
    failures_by_user = _group_by((e for e in events if not e.success), lambda e: e.username)
    alerts: List[Alert] = []

    for username in sorted(failures_by_user):
        clusters = _qualifying_clusters(
            failures_by_user[username],
            config.window,
            key=lambda e: e.source_ip,
            qualifies=lambda _counter, size: size >= threshold,
        )
        for cluster in clusters:
            total = len(cluster)
            sources = sorted({e.source_ip for e in cluster})
            span = cluster[-1].timestamp - cluster[0].timestamp
            severity = "high" if total >= 2 * threshold else "medium"
            explanation = (
                f"{total} failed logins for account '{username}' were recorded between "
                f"{format_timestamp(cluster[0].timestamp)} and {format_timestamp(cluster[-1].timestamp)} "
                f"(a span of {format_duration(span)}), coming from {describe_sources(sources)}. "
                f"The rule matches when an account has at least {threshold} failed logins inside "
                f"any {config.window_minutes}-minute window."
            )
            alerts.append(_build_alert(REPEATED_FAILURES, severity, [username], sources, cluster, explanation))
    return alerts


# ---------------------------------------------------------------------------
# Rule 2: success after repeated failures
# ---------------------------------------------------------------------------

def _success_after_failures(events: Sequence[LoginEvent], config: DetectionConfig) -> List[Alert]:
    threshold = config.success_after_failures_threshold
    window = config.window
    alerts: List[Alert] = []
    events_by_user = _group_by(events, lambda e: e.username)

    for username in sorted(events_by_user):
        pending: List[LoginEvent] = []  # failures since this account's last success
        for event in events_by_user[username]:
            if not event.success:
                pending.append(event)
                continue
            recent = [f for f in pending if event.timestamp - f.timestamp <= window]
            pending = []  # a success always resets the run of failures
            if len(recent) < threshold:
                continue

            failure_sources = sorted({f.source_ip for f in recent})
            relation = (
                "is one of those addresses"
                if event.source_ip in failure_sources
                else "is not one of those addresses"
            )
            severity = "high" if len(recent) >= 2 * threshold else "medium"
            explanation = (
                f"Account '{username}' had {len(recent)} failed logins in the {config.window_minutes} "
                f"minutes before a successful login at {format_timestamp(event.timestamp)}. "
                f"The failures came from {describe_sources(failure_sources)}; the successful login came "
                f"from {event.source_ip}, which {relation}. The rule matches when at least {threshold} "
                f"failures occur within {config.window_minutes} minutes before a success."
            )
            alerts.append(
                _build_alert(
                    SUCCESS_AFTER_FAILURES,
                    severity,
                    [username],
                    failure_sources + [event.source_ip],
                    recent + [event],
                    explanation,
                )
            )
    return alerts


# ---------------------------------------------------------------------------
# Rule 3: one source failing against many accounts
# ---------------------------------------------------------------------------

def _multi_account_failures(events: Sequence[LoginEvent], config: DetectionConfig) -> List[Alert]:
    threshold = config.spray_account_threshold
    failures_by_source = _group_by((e for e in events if not e.success), lambda e: e.source_ip)
    alerts: List[Alert] = []

    for source_ip in sorted(failures_by_source):
        clusters = _qualifying_clusters(
            failures_by_source[source_ip],
            config.window,
            key=lambda e: e.username,
            qualifies=lambda counter, _size: len(counter) >= threshold,
        )
        for cluster in clusters:
            accounts = sorted({e.username for e in cluster})
            severity = "high" if len(accounts) >= 2 * threshold else "medium"
            explanation = (
                f"Source address {source_ip} produced {len(cluster)} failed logins against "
                f"{len(accounts)} different accounts between {format_timestamp(cluster[0].timestamp)} and "
                f"{format_timestamp(cluster[-1].timestamp)}. The rule matches when one source fails against "
                f"at least {threshold} different accounts inside any {config.window_minutes}-minute window, "
                f"a pattern often seen in password spraying but also in shared-address or misconfigured clients."
            )
            alerts.append(
                _build_alert(MULTI_ACCOUNT_FAILURES, severity, accounts, [source_ip], cluster, explanation)
            )
    return alerts


# ---------------------------------------------------------------------------
# Rule 4: successful login outside an explicitly configured schedule
# ---------------------------------------------------------------------------

def _inside_schedule(hour: int, start: int, end: int) -> bool:
    if start < end:
        return start <= hour < end
    return hour >= start or hour < end  # schedule crosses midnight


def _unusual_time(events: Sequence[LoginEvent], config: DetectionConfig) -> List[Alert]:
    start, end = config.schedule_start_hour, config.schedule_end_hour
    outside = [
        e for e in events if e.success and not _inside_schedule(e.timestamp.hour, start, end)
    ]
    groups: Dict[tuple, List[LoginEvent]] = defaultdict(list)
    for event in outside:
        groups[(event.username, event.timestamp.date())].append(event)

    alerts: List[Alert] = []
    for (username, day), group in sorted(groups.items(), key=lambda item: (item[0][1], item[0][0])):
        sources = sorted({e.source_ip for e in group})
        times = ", ".join(e.timestamp.strftime("%H:%M:%S") for e in group[:5])
        more = f" and {len(group) - 5} more" if len(group) > 5 else ""
        explanation = (
            f"Account '{username}' had {len(group)} successful login(s) on {day.isoformat()} outside the "
            f"expected hours {start:02d}:00 to {end:02d}:00 (at {times}{more}) from {describe_sources(sources)}. "
            f"This rule only runs because an expected schedule was configured."
        )
        alerts.append(_build_alert(UNUSUAL_TIME, "low", [username], sources, group, explanation))
    return alerts
