"""Small text-formatting helpers used in alert explanations and templates."""
from __future__ import annotations

from datetime import datetime, timedelta
from typing import Sequence


def format_timestamp(value: datetime) -> str:
    """All timestamps are shown in UTC (see the parser for how inputs are normalised)."""
    return value.strftime("%Y-%m-%d %H:%M:%S") + " UTC"


def format_duration(delta: timedelta) -> str:
    seconds = int(delta.total_seconds())
    if seconds < 60:
        return f"{seconds} second{'s' if seconds != 1 else ''}"
    minutes, sec = divmod(seconds, 60)
    if minutes < 60:
        return f"{minutes} min {sec} s" if sec else f"{minutes} min"
    hours, minutes = divmod(minutes, 60)
    if hours < 24:
        return f"{hours} h {minutes} min" if minutes else f"{hours} h"
    days, hours = divmod(hours, 24)
    return f"{days} d {hours} h" if hours else f"{days} d"


def describe_sources(addresses: Sequence[str]) -> str:
    """Plain-language description of one or more source addresses."""
    count = len(addresses)
    if count == 1:
        return f"one source address ({addresses[0]})"
    if count <= 5:
        return f"{count} different source addresses ({', '.join(addresses)})"
    return f"{count} different source addresses"
