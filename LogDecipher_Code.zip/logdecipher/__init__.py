"""LogDecipher: an explainable cybersecurity log analysis platform (educational project)."""

__version__ = "1.0.0"


def create_app(*args, **kwargs):
    """Create the Flask application (imported lazily so the engine can be used without Flask)."""
    from .app import create_app as _create_app

    return _create_app(*args, **kwargs)
