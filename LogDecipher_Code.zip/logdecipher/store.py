"""A tiny in-memory store for analysis results.

LogDecipher has no database. The parsed events live in server memory only, keyed by a random
token kept in the person's session cookie. Entries expire after a while and the store holds a
small number of them, so uploaded data is not retained longer than needed. Restarting the
server clears everything. This design suits a single-user local demo, not a multi-user service.
"""
from __future__ import annotations

import secrets
import threading
import time
from collections import OrderedDict
from typing import Callable, Optional, Tuple

from .analysis import Analysis


class AnalysisStore:
    def __init__(
        self,
        max_items: int = 8,
        ttl_seconds: float = 2 * 60 * 60,
        clock: Callable[[], float] = time.monotonic,
    ) -> None:
        self._max_items = max_items
        self._ttl = ttl_seconds
        self._clock = clock
        self._items: "OrderedDict[str, Tuple[float, Analysis]]" = OrderedDict()
        self._lock = threading.Lock()

    def _purge_expired(self) -> None:
        now = self._clock()
        for token in [t for t, (stamp, _a) in self._items.items() if now - stamp > self._ttl]:
            del self._items[token]

    def put(self, analysis: Analysis) -> str:
        token = secrets.token_urlsafe(24)
        with self._lock:
            self._purge_expired()
            self._items[token] = (self._clock(), analysis)
            while len(self._items) > self._max_items:
                self._items.popitem(last=False)  # drop the least recently used
        return token

    def get(self, token: Optional[str]) -> Optional[Analysis]:
        if not token:
            return None
        with self._lock:
            self._purge_expired()
            entry = self._items.get(token)
            if entry is None:
                return None
            self._items[token] = (self._clock(), entry[1])  # touching refreshes the expiry
            self._items.move_to_end(token)
            return entry[1]

    def delete(self, token: Optional[str]) -> None:
        if not token:
            return
        with self._lock:
            self._items.pop(token, None)

    def __len__(self) -> int:
        with self._lock:
            self._purge_expired()
            return len(self._items)
