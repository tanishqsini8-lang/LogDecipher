"""Alert filtering and sorting for the dashboard and the CSV export."""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Dict, Iterable, List, Mapping, Optional, Tuple

from .engine.models import SEVERITY_ORDER, SEVERITY_RANK, Alert

SORT_OPTIONS = {
    "severity": "Severity (highest first)",
    "newest": "Most recent first",
    "oldest": "Oldest first",
}
DEFAULT_SORT = "severity"
MAX_TEXT_LENGTH = 128


@dataclass(frozen=True)
class AlertFilter:
    severity: str = ""
    rule: str = ""
    username: str = ""
    source_ip: str = ""
    time_from: Optional[datetime] = None
    time_to: Optional[datetime] = None
    sort: str = DEFAULT_SORT
    time_from_raw: str = ""  # canonical text for re-filling the form
    time_to_raw: str = ""

    def query(self) -> Dict[str, str]:
        """Only the filters that are set, ready to be put in a link."""
        values = {
            "severity": self.severity,
            "rule": self.rule,
            "username": self.username,
            "source_ip": self.source_ip,
            "time_from": self.time_from_raw,
            "time_to": self.time_to_raw,
        }
        if self.sort != DEFAULT_SORT:
            values["sort"] = self.sort
        return {key: value for key, value in values.items() if value}

    @property
    def is_active(self) -> bool:
        return any((self.severity, self.rule, self.username, self.source_ip, self.time_from, self.time_to))


def _parse_moment(text: str, end_of_minute: bool) -> Optional[datetime]:
    text = text.strip()
    try:
        moment = datetime.fromisoformat(text)
    except ValueError:
        return None
    if moment.tzinfo is not None:
        moment = moment.astimezone(timezone.utc).replace(tzinfo=None)
    if not 1970 <= moment.year <= 2100:
        return None
    if end_of_minute and len(text) <= 16 and moment.second == 0:
        moment += timedelta(seconds=59)  # "to 13:10" includes the whole 13:10 minute
    return moment


def _canonical(moment_text: str) -> str:
    moment = datetime.fromisoformat(moment_text.strip())
    if moment.tzinfo is not None:
        moment = moment.astimezone(timezone.utc).replace(tzinfo=None)
    return moment.isoformat(timespec="minutes" if moment.second == 0 else "seconds")


def parse_filters(args: Mapping[str, str], valid_rules: Iterable[str]) -> Tuple[AlertFilter, List[str]]:
    """Read filter values from the query string. Invalid values are dropped and reported."""
    errors: List[str] = []
    valid_rules = set(valid_rules)

    def text(name: str) -> str:
        return (args.get(name) or "").strip()[:MAX_TEXT_LENGTH]

    severity = text("severity").lower()
    if severity and severity not in SEVERITY_ORDER:
        errors.append("Unknown severity ignored.")
        severity = ""

    rule = text("rule")
    if rule and rule not in valid_rules:
        errors.append("Unknown rule ignored.")
        rule = ""

    sort = text("sort") or DEFAULT_SORT
    if sort not in SORT_OPTIONS:
        sort = DEFAULT_SORT

    moments: Dict[str, Tuple[Optional[datetime], str]] = {}
    for name, end_of_minute in (("time_from", False), ("time_to", True)):
        raw = text(name)
        parsed = _parse_moment(raw, end_of_minute) if raw else None
        if raw and parsed is None:
            errors.append(f"'{name.replace('_', ' ')}' is not a valid date and time and was ignored.")
        moments[name] = (parsed, _canonical(raw) if parsed else "")

    time_from, from_raw = moments["time_from"]
    time_to, to_raw = moments["time_to"]
    if time_from and time_to and time_from > time_to:
        errors.append("The start time is after the end time, so both were ignored.")
        time_from = time_to = None
        from_raw = to_raw = ""

    return (
        AlertFilter(
            severity=severity,
            rule=rule,
            username=text("username"),
            source_ip=text("source_ip"),
            time_from=time_from,
            time_to=time_to,
            sort=sort,
            time_from_raw=from_raw,
            time_to_raw=to_raw,
        ),
        errors,
    )


def apply_filters(alerts: Iterable[Alert], flt: AlertFilter) -> List[Alert]:
    username_query = flt.username.casefold()
    source_query = flt.source_ip.casefold()
    matching: List[Alert] = []
    for alert in alerts:
        if flt.severity and alert.severity != flt.severity:
            continue
        if flt.rule and alert.rule_id != flt.rule:
            continue
        if username_query and not any(username_query in name.casefold() for name in alert.usernames):
            continue
        if source_query and not any(source_query in ip.casefold() for ip in alert.source_ips):
            continue
        if flt.time_from and alert.end < flt.time_from:
            continue
        if flt.time_to and alert.start > flt.time_to:
            continue
        matching.append(alert)

    matching.sort(key=lambda a: a.alert_id)  # stable base order
    if flt.sort == "oldest":
        matching.sort(key=lambda a: a.start)
    elif flt.sort == "newest":
        matching.sort(key=lambda a: a.start, reverse=True)
    else:  # severity, newest first within the same severity
        matching.sort(key=lambda a: a.start, reverse=True)
        matching.sort(key=lambda a: SEVERITY_RANK[a.severity], reverse=True)
    return matching
