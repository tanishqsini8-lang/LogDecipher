"""Flask application factory for LogDecipher."""
from __future__ import annotations

import hmac
import os
import re
import secrets
from pathlib import Path
from typing import Optional, Tuple

from flask import (
    Flask,
    Response,
    abort,
    flash,
    redirect,
    render_template,
    request,
    session,
    url_for,
)
from werkzeug.exceptions import HTTPException

from .analysis import Analysis, build_analysis
from .charts import timeline_chart
from .engine.config import ConfigError, DetectionConfig
from .engine.detector import analyze
from .engine.formatting import format_timestamp
from .engine.models import SEVERITY_ORDER
from .engine.parser import REQUIRED_COLUMNS, CsvValidationError, parse_login_csv
from .engine.rules import RULE_ORDER, RULES, threshold_lines
from .engine.summary import describe_bucket_size
from .exporter import alerts_to_csv
from .filters import SORT_OPTIONS, apply_filters, parse_filters
from .store import AnalysisStore

ALERT_ID_PATTERN = re.compile(r"^LD-\d{4,}$")
DEFAULT_SAMPLE_PATH = Path(__file__).resolve().parent.parent / "data" / "sample_logins.csv"
MAX_EVENTS_ON_DETAIL_PAGE = 200
UPLOAD_OVERHEAD_BYTES = 128 * 1024  # room for form fields on top of the file itself

CONTENT_SECURITY_POLICY = (
    "default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self'; "
    "font-src 'self'; connect-src 'self'; form-action 'self'; base-uri 'none'; "
    "frame-ancestors 'none'"
)

ERROR_PAGES = {
    400: ("Request not accepted", "The request could not be processed. If this page was open for a while, reload it and try again."),
    404: ("Page not found", "That page does not exist, or the analysis it belonged to is no longer loaded."),
    405: ("Method not allowed", "That action is not available at this address."),
    413: ("File too large", "The upload is larger than the allowed size."),
    500: ("Something went wrong", "LogDecipher could not complete that request. Nothing was changed. Try again, or load the sample dataset."),
}


def create_app(test_config: Optional[dict] = None) -> Flask:
    app = Flask(__name__)
    app.config.from_mapping(
        # A fresh random key per start keeps the repository free of secrets. Sessions simply
        # reset when the server restarts. Set LOGDECIPHER_SECRET_KEY to keep them across restarts.
        SECRET_KEY=os.environ.get("LOGDECIPHER_SECRET_KEY") or secrets.token_hex(32),
        MAX_UPLOAD_BYTES=2 * 1024 * 1024,
        MAX_ROWS=50_000,
        ALERT_TABLE_LIMIT=100,
        SAMPLE_DATA_PATH=str(DEFAULT_SAMPLE_PATH),
        SESSION_COOKIE_HTTPONLY=True,
        SESSION_COOKIE_SAMESITE="Lax",
        SESSION_COOKIE_NAME="logdecipher_session",
        DEBUG=False,
    )
    if test_config:
        app.config.update(test_config)
    if not (test_config and "MAX_CONTENT_LENGTH" in test_config):
        app.config["MAX_CONTENT_LENGTH"] = app.config["MAX_UPLOAD_BYTES"] + UPLOAD_OVERHEAD_BYTES

    store = AnalysisStore()
    app.extensions["logdecipher_store"] = store

    # ------------------------------------------------------------------ helpers

    def current_analysis() -> Optional[Analysis]:
        return store.get(session.get("analysis_id"))

    def csrf_token() -> str:
        token = session.get("csrf_token")
        if not token:
            token = secrets.token_urlsafe(32)
            session["csrf_token"] = token
        return token

    def size_label(num_bytes: int) -> str:
        return f"{num_bytes / (1024 * 1024):g} MB"

    def clean_filename(name: Optional[str]) -> str:
        base = os.path.basename((name or "").replace("\\", "/"))
        base = "".join(ch if ch.isprintable() else "?" for ch in base)[:80].strip()
        return base or "uploaded file"

    def config_from_form(form) -> DetectionConfig:
        def whole_number(field: str, label: str, default: Optional[int]) -> Optional[int]:
            raw = (form.get(field) or "").strip()
            if raw == "":
                return default
            try:
                return int(raw)
            except ValueError:
                raise ConfigError(f"{label} must be a whole number.") from None

        defaults = DetectionConfig()
        config = DetectionConfig(
            window_minutes=whole_number("window_minutes", "Time window", defaults.window_minutes),
            failure_threshold=whole_number("failure_threshold", "Repeated-failure threshold", defaults.failure_threshold),
            success_after_failures_threshold=whole_number(
                "success_after_failures_threshold",
                "Success-after-failures threshold",
                defaults.success_after_failures_threshold,
            ),
            spray_account_threshold=whole_number(
                "spray_account_threshold", "Multi-account threshold", defaults.spray_account_threshold
            ),
            schedule_start_hour=whole_number("schedule_start_hour", "Expected start hour", None),
            schedule_end_hour=whole_number("schedule_end_hour", "Expected end hour", None),
        )
        config.validate()
        return config

    def start_analysis(raw: bytes, label: str, config: DetectionConfig) -> bool:
        try:
            parsed = parse_login_csv(
                raw,
                max_bytes=app.config["MAX_UPLOAD_BYTES"],
                max_rows=app.config["MAX_ROWS"],
            )
        except CsvValidationError as exc:
            flash(str(exc), "error")
            return False

        alerts = analyze(parsed.events, config)
        analysis = build_analysis(parsed, alerts, config, label)
        store.delete(session.get("analysis_id"))
        session["analysis_id"] = store.put(analysis)

        noun = "alert group" if len(alerts) == 1 else "alert groups"
        flash(f"Analyzed {len(parsed.events):,} events from {label}: {len(alerts)} {noun}.", "success")
        if parsed.skipped_rows:
            flash(
                f"{parsed.skipped_rows:,} row(s) could not be read and were skipped. "
                "Details are listed at the bottom of the dashboard.",
                "warning",
            )
        return True

    def render_error(code: int, message: Optional[str] = None) -> Tuple[str, int]:
        title, default_message = ERROR_PAGES.get(code, ERROR_PAGES[500])
        return render_template("error.html", code=code, title=title, message=message or default_message), code

    # --------------------------------------------------------- template helpers

    app.jinja_env.globals["csrf_token"] = csrf_token
    app.jinja_env.globals["threshold_lines"] = threshold_lines
    app.jinja_env.filters["ts"] = format_timestamp
    app.jinja_env.filters["thousands"] = lambda value: f"{value:,}"

    @app.context_processor
    def inject_globals():
        return {
            "analysis_loaded": current_analysis() is not None,
            "limits": {
                "max_size": size_label(app.config["MAX_UPLOAD_BYTES"]),
                "max_bytes": app.config["MAX_UPLOAD_BYTES"],
                "max_rows": app.config["MAX_ROWS"],
            },
        }

    # ------------------------------------------------------------- security

    @app.before_request
    def protect_state_changing_requests():
        if request.method == "POST":
            sent = (request.form.get("csrf_token") or "").encode()
            expected = (session.get("csrf_token") or "").encode()
            if not expected or not hmac.compare_digest(sent, expected):
                abort(400)

    @app.after_request
    def add_security_headers(response: Response) -> Response:
        response.headers["Content-Security-Policy"] = CONTENT_SECURITY_POLICY
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
        response.headers["Cross-Origin-Opener-Policy"] = "same-origin"
        if request.endpoint != "static":
            response.headers["Cache-Control"] = "no-store"
        return response

    @app.errorhandler(413)
    def too_large(_error):
        limit = size_label(app.config["MAX_UPLOAD_BYTES"])
        return render_error(413, f"The upload is larger than the {limit} limit. Use a smaller file.")

    @app.errorhandler(HTTPException)
    def http_error(error: HTTPException):
        return render_error(error.code or 500)

    @app.errorhandler(Exception)
    def unexpected_error(error: Exception):
        # Details go to the server log only; the person sees a generic message, never a stack trace.
        app.logger.exception("Unhandled error: %s", error)
        return render_error(500)

    # --------------------------------------------------------------- routes

    @app.get("/")
    def dashboard():
        analysis = current_analysis()
        if analysis is None:
            return render_template(
                "dashboard.html",
                analysis=None,
                form_config=DetectionConfig(),
                required_columns=REQUIRED_COLUMNS,
            )

        flt, filter_errors = parse_filters(request.args, RULES.keys())
        matching = apply_filters(analysis.alerts, flt)
        shown = matching[: app.config["ALERT_TABLE_LIMIT"]]
        summary = analysis.summary
        max_severity_count = max(summary.severity_counts.values(), default=0)
        return render_template(
            "dashboard.html",
            analysis=analysis,
            summary=summary,
            form_config=analysis.config,
            required_columns=REQUIRED_COLUMNS,
            flt=flt,
            filter_errors=filter_errors,
            filter_query=flt.query(),
            matching=matching,
            shown=shown,
            severities=SEVERITY_ORDER,
            max_severity_count=max_severity_count,
            rules=[RULES[rule_id] for rule_id in sorted(RULES, key=RULE_ORDER.get)],
            sort_options=SORT_OPTIONS,
            chart=timeline_chart(analysis.timeline),
            bucket_size=describe_bucket_size(analysis.timeline.bucket_minutes),
            timeline=analysis.timeline,
            threshold_lines=threshold_lines,
        )

    @app.post("/analyze")
    def analyze_upload():
        try:
            config = config_from_form(request.form)
        except ConfigError as exc:
            flash(str(exc), "error")
            return redirect(url_for("dashboard"))

        upload = request.files.get("logfile")
        if upload is None or not upload.filename:
            flash("Choose a CSV file to analyze, or use the sample dataset.", "error")
            return redirect(url_for("dashboard"))
        if not upload.filename.lower().endswith(".csv"):
            flash("Only .csv files are accepted.", "error")
            return redirect(url_for("dashboard"))

        raw = upload.stream.read(app.config["MAX_UPLOAD_BYTES"] + 1)  # never read more than the limit
        start_analysis(raw, clean_filename(upload.filename), config)
        return redirect(url_for("dashboard"))

    @app.post("/sample")
    def load_sample():
        try:
            config = config_from_form(request.form)
        except ConfigError as exc:
            flash(str(exc), "error")
            return redirect(url_for("dashboard"))
        raw = Path(app.config["SAMPLE_DATA_PATH"]).read_bytes()
        start_analysis(raw, "sample_logins.csv (fictional sample)", config)
        return redirect(url_for("dashboard"))

    @app.post("/reset")
    def reset():
        store.delete(session.pop("analysis_id", None))
        flash("The loaded analysis was cleared from memory.", "info")
        return redirect(url_for("dashboard"))

    @app.get("/alerts/<alert_id>")
    def alert_detail(alert_id: str):
        if not ALERT_ID_PATTERN.match(alert_id):
            abort(404)
        analysis = current_analysis()
        if analysis is None:
            flash("No analysis is loaded. Upload a file or load the sample dataset first.", "info")
            return redirect(url_for("dashboard"))
        alert = analysis.alerts_by_id.get(alert_id)
        if alert is None:
            abort(404)
        lines = alert.event_lines[:MAX_EVENTS_ON_DETAIL_PAGE]
        return render_template(
            "alert.html",
            analysis=analysis,
            alert=alert,
            rule=RULES[alert.rule_id],
            events=[analysis.events_by_line[line] for line in lines],
            hidden_events=max(len(alert.event_lines) - len(lines), 0),
        )

    @app.get("/export.csv")
    def export_csv():
        analysis = current_analysis()
        if analysis is None:
            flash("No analysis is loaded. Upload a file or load the sample dataset first.", "info")
            return redirect(url_for("dashboard"))
        flt, _errors = parse_filters(request.args, RULES.keys())
        body = alerts_to_csv(apply_filters(analysis.alerts, flt))
        return Response(
            body,
            mimetype="text/csv",
            headers={
                "Content-Disposition": 'attachment; filename="logdecipher_findings.csv"',
            },
        )

    @app.get("/rules")
    def rules_page():
        analysis = current_analysis()
        config = analysis.config if analysis else DetectionConfig()
        return render_template(
            "rules.html",
            analysis=analysis,
            config=config,
            rules=[RULES[rule_id] for rule_id in sorted(RULES, key=RULE_ORDER.get)],
            threshold_lines=threshold_lines,
        )

    return app
