/* LogDecipher: small progressive enhancements. The app works without JavaScript. */
(function () {
  "use strict";

  // Check the chosen file's size in the browser for fast feedback. The server checks again.
  document.querySelectorAll('input[type="file"][data-max-bytes]').forEach(function (input) {
    var hint = document.getElementById("file-hint");
    var original = hint ? hint.textContent : "";
    input.addEventListener("change", function () {
      var file = input.files && input.files[0];
      input.setCustomValidity("");
      if (hint) { hint.textContent = original; }
      if (!file) { return; }
      var limit = Number(input.getAttribute("data-max-bytes"));
      if (file.size > limit) {
        var message = "This file is " + (file.size / 1048576).toFixed(1) + " MB, which is over the " +
          (limit / 1048576) + " MB limit.";
        input.setCustomValidity(message);
        if (hint) { hint.textContent = message; }
        input.reportValidity();
      }
    });
  });

  // Show progress while the server analyzes, and prevent double submission.
  document.querySelectorAll("form[data-busy-text]").forEach(function (form) {
    form.addEventListener("submit", function (event) {
      var submitter = event.submitter;
      var busyText = form.getAttribute("data-busy-text");
      window.setTimeout(function () {
        form.setAttribute("aria-busy", "true");
        form.querySelectorAll('button[type="submit"]').forEach(function (button) {
          button.disabled = true;
        });
        if (submitter) {
          submitter.setAttribute("data-original-text", submitter.textContent);
          submitter.textContent = busyText;
        }
      }, 0);
    });
  });

  // Restore the buttons if the person returns with the browser's Back button.
  window.addEventListener("pageshow", function () {
    document.querySelectorAll("form[data-busy-text]").forEach(function (form) {
      form.removeAttribute("aria-busy");
      form.querySelectorAll('button[type="submit"]').forEach(function (button) {
        button.disabled = false;
        var original = button.getAttribute("data-original-text");
        if (original) { button.textContent = original; button.removeAttribute("data-original-text"); }
      });
    });
  });
})();
