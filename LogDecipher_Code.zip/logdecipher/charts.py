"""Geometry for the server-rendered SVG charts.

Charts are drawn as inline SVG from real data so they need no JavaScript and work under a strict
Content-Security-Policy. All numbers are computed here; templates only place the shapes.
"""
from __future__ import annotations

import math
from typing import Dict, List

from .engine.summary import Timeline


def nice_max(value: int) -> int:
    """Round up to 1, 2, 5 or 10 times a power of ten so axis ticks are readable."""
    if value <= 1:
        return 1
    exponent = 10 ** int(math.floor(math.log10(value)))
    for factor in (1, 2, 5, 10):
        if value <= factor * exponent:
            return factor * exponent
    return 10 * exponent


def timeline_chart(timeline: Timeline, width: int = 720, height: int = 240) -> Dict:
    left, right, top, bottom = 44, 8, 10, 32
    plot_width = width - left - right
    plot_height = height - top - bottom
    buckets = timeline.buckets
    count = len(buckets)
    y_max = nice_max(timeline.max_total)
    slot = plot_width / count
    bar_width = max(slot * 0.78, 1.0)

    bars: List[Dict] = []
    for index, bucket in enumerate(buckets):
        x = left + index * slot + (slot - bar_width) / 2
        total_height = plot_height * bucket.total / y_max
        flagged_height = plot_height * bucket.flagged / y_max
        bars.append(
            {
                "x": round(x, 2),
                "width": round(bar_width, 2),
                "total_y": round(top + plot_height - total_height, 2),
                "total_height": round(total_height, 2),
                "flagged_y": round(top + plot_height - flagged_height, 2),
                "flagged_height": round(flagged_height, 2),
                "label": (
                    f"{bucket.start:%b %d, %H:%M} UTC: {bucket.total} event"
                    f"{'s' if bucket.total != 1 else ''}, {bucket.flagged} in alerts"
                ),
            }
        )

    tick_values = sorted({0, y_max // 2, y_max}) if y_max >= 2 else [0, 1]
    ticks = [
        {"y": round(top + plot_height - plot_height * value / y_max, 2), "label": str(value)}
        for value in tick_values
    ]

    def x_label(index: int, anchor: str, x: float) -> Dict:
        return {"x": round(x, 2), "anchor": anchor, "text": f"{buckets[index].start:%b %d %H:%M}"}

    labels = [x_label(0, "start", left)]
    if count >= 5:
        middle = count // 2
        labels.append(x_label(middle, "middle", left + (middle + 0.5) * slot))
    if count >= 2:
        labels.append(x_label(count - 1, "end", width - right))

    return {
        "width": width,
        "height": height,
        "left": left,
        "plot_right": width - right,
        "plot_bottom": top + plot_height,
        "label_y": height - 10,
        "bars": bars,
        "ticks": ticks,
        "x_labels": labels,
    }
