"""The result of one analysis run, kept in memory while the person explores it."""
from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Dict, List, Sequence

from .engine.config import DetectionConfig
from .engine.models import Alert, LoginEvent
from .engine.parser import ParseResult, RowIssue
from .engine.summary import Summary, Timeline, build_summary, build_timeline, flagged_lines


@dataclass
class Analysis:
    source_label: str
    config: DetectionConfig
    events_by_line: Dict[int, LoginEvent]
    alerts: List[Alert]
    alerts_by_id: Dict[str, Alert]
    summary: Summary
    timeline: Timeline
    issues: List[RowIssue]
    skipped_rows: int
    total_rows: int
    created_at: datetime = field(
        default_factory=lambda: datetime.now(timezone.utc).replace(tzinfo=None)
    )

    @property
    def issues_truncated(self) -> bool:
        return self.skipped_rows > len(self.issues)


def build_analysis(
    parsed: ParseResult,
    alerts: Sequence[Alert],
    config: DetectionConfig,
    source_label: str,
) -> Analysis:
    flagged = flagged_lines(alerts)
    return Analysis(
        source_label=source_label,
        config=config,
        events_by_line={e.line: e for e in parsed.events},
        alerts=list(alerts),
        alerts_by_id={a.alert_id: a for a in alerts},
        summary=build_summary(parsed.events, alerts),
        timeline=build_timeline(parsed.events, flagged),
        issues=list(parsed.issues),
        skipped_rows=parsed.skipped_rows,
        total_rows=parsed.total_rows,
    )
